# CatLog

CatLog runs an obfuscated Roblox script **once** inside a fake Roblox/executor
and writes back everything the script actually did, as readable Luau. It ships
with a Discord bot that does the same thing from a chat upload.

```
.l          dump a script: attach it, paste it in a ``` code block ``` (or
            `inline`), reply `.l` to a message that has one, or paste a link —
            a whole loadstring(game:HttpGet("https://…"))() line works
.luraph     run the dedicated Luraph source lifter on an attachment, pasted
            script, zip, reply, or link; only v14.7–v14.9 and v15.0–v15.1
.get        fetch the script behind a link and send it back untouched
.detect     name the obfuscator, nothing is executed
.help       what the bot does (two-page panel)
.links      every official link
.support    support link + a private ticket modal
.ticket     open the ticket modal directly
```

`.l` and `.luraph` also work as a **reply** to a message that carries the file,
so you do not have to upload it twice.

`.luraph` uses the bundled version-specific source lifter directly: v14.7–v14.9
are experimental, and v15.0–v15.1 use the v15 lifter. Unlike `.l`, it does not
fall back to a behavior trace or label one as deobfuscated source; when a source
lift fails, it reports that instead. It requires Node.js 18+ and the locally
built `luau`, `luau-ast` tools. Other Luraph versions are not claimed as lifted.

Every `.l` result carries **exactly one comment**, and it is this one. `.luraph`
returns the lifter's source output directly:

```lua
-- Logged with Catmio | https://discord.gg/2aDSEyhcq
```

## Install

```bash
pip install -r requirements.txt          # discord.py + lupa
scripts/build_luau.sh                    # builds luau + luau-compile + luau-ast for THIS CPU
cp .env.example .env                     # then edit it
python run.py
```

### The Luau binaries are not in this repo, on purpose

They are compiled C++ for one CPU. A binary built on x86-64 is useless on
aarch64 (a Raspberry Pi, an ARM VPS, a Graviton instance) and dies with
`Exec format error` — or, worse, `FileNotFoundError` from somewhere deep in
`subprocess`. The official Luau release only ships **x86-64** (ubuntu, windows)
and a universal macOS build, so on ARM there is nothing to download.

| your machine | do this |
|---|---|
| x86-64 Linux, trace-only | `scripts/fetch_luau.sh` (downloads the release, ~6 MB) |
| any architecture, including x86-64 with Luraph lifting | `scripts/build_luau.sh` (git + cmake + C++ compiler, ~3 min) |
| anywhere, no network rules | `scripts/build_luau.sh` always works if the toolchain is there |

The standard release download does not include `luau-ast`. Luraph static lifting
requires it, so use `scripts/build_luau.sh` to build/install `luau`,
`luau-compile` and `luau-ast` together. Node.js 18+ is required only for the
Luraph engine.

Both install into `.luau-local/` (gitignored). `LUAU_BIN=/some/dir` overrides
the lookup. The bot checks **architecture**, not just presence: if `luau` was
built for another CPU it says so in one sentence, and `.l` refuses with
"CatLog cannot run right now: luau is built for x86_64, this machine is
aarch64", instead of leaking a traceback to the user.

**Developer Portal → Bot → Privileged Gateway Intents → Message Content Intent: ON.**
A prefix bot cannot see `.l` without it. The bot asks for that intent and nothing
else — no members, no presences, no reactions, no voice. If it is off, Discord
refuses the connection and `run.py` prints exactly that sentence instead of a
traceback.

**No voice.** There is no voice code in this project, so `PyNaCl`/`davey` are not
needed and the "voice will NOT be supported" warning is switched off — it
advertised a feature that was never offered.

```dotenv
DISCORD_TOKEN=...                         # required
SUPPORT_SERVER=https://discord.gg/2aDSEyhcq
WEBSITE=
SOURCE_REPO=
DOCS_URL=
```

## How it works

| piece | what it does |
|---|---|
| `catlog/catlog.luau` | the runtime: fake Roblox + executor inside a real Luau VM, records every call, property write, remote and error |
| `catlog/harness.py` | builds the harness, runs it, collects the trace |
| `catlog/engine.py` | turns the trace into readable Luau and keeps the recovered payloads |
| `catlog/redact.py` | strips every comment, keeps the banner, and refuses to deliver code that no longer compiles |
| `catlog/luraph/` | MIT-licensed Luraph VM lifter, version-specific mappers and runtime; no upstream sample corpus or test files are vendored |
| `bot/archive.py` | reads a `.zip` in memory (no extraction to disk) and hands its files back |
| `bot/chunker.py` | splits an oversized result at a point that cannot be inside a string |
| `bot/` | Discord front end: prefix commands only, no slash commands, no voice |

## Luraph coverage

Luraph inputs are routed to a vendored MIT-licensed VM lifter (license and
attribution are in `catlog/luraph/LICENSE`). The vendor source is
[`unknown0x75/Luraph_v15_1_Deob`](https://github.com/unknown0x75/Luraph_v15_1_Deob),
commit `1a758ba299cfe6172e23a27a2077c9e3068de8d3`, distributed under MIT; CatLog's
adapter and version routing are local changes. The integration includes only
the engine/runtime files needed to run it; upstream samples, test suites and
prebuilt binaries are intentionally not copied into CatLog.

| version | current status |
|---|---|
| v15.0 | Routed to the v15 VM lifter; output quality depends on the sample/layout. |
| v15.1 | Routed through the v15 lifter. I ran four upstream reference samples and got byte-identical outputs; this is useful validation, not proof of universal coverage. |
| v14.7 | Dedicated mapper/lifter, experimental and sample-dependent. |
| v14.8–v14.9 | Dedicated mapper/lifter, experimental; some builds produce only a behavior trace or partial lift. |
| Other banner versions (including v1–v14.6, v15.2+, and future releases) | Version is recognized and routed to behavior tracing only; no bytecode lift is claimed. |

I sampled the smallest non-empty file from each of the 49 version folders in
[`terrorlua/obfuscator-samples`](https://github.com/terrorlua/obfuscator-samples/tree/main/Luraph)
without copying the corpus into CatLog: 45 runs exited successfully and 42
wrote non-empty output. This is only a routing/trace smoke check, not a source-
recovery score. The selected v14.6.0, v14.8 and v14.9 files timed out at 120 s;
a short v14.3 file failed. Those cases remain known gaps.

Version routing uses the Luraph banner where present; if the banner is stripped,
CatLog cannot reliably distinguish every historical VM generation. A behavior
trace records executed operations; it is **not** recovered source and may miss
paths that did not execute. Recovery of names, comments, encrypted functions,
hidden branches, and server-keyed payloads is not guaranteed. Large
inputs may need a longer runtime budget. Node.js 18+ and the `luau-ast` binary
are required for static Luraph lifting; without them CatLog falls back to its
normal trace path.

## Security boundaries

| attack | defence |
|---|---|
| script reads `../../bot/main.py` / `.env` | the executor's filesystem is an **in-memory table**; there are no disk calls to abuse |
| script calls `io.popen` / `os.execute` | that library is not present; the call is recorded as text and nothing runs |
| script reads `DISCORD_TOKEN` | the token is removed from the child process environment before it starts |
| hostile attachment filename (`; rm -rf ~`) | argv is a **list**, the file is written to a temp dir with a fixed name, and no shell is involved |
| traceback leaks paths | users only ever see fixed sentences; tracebacks go to the log |
| source disclosure | there is no `eval/exec/sh/cat/ls/env/debug/source` command, by design |
| zip traversal (`../../etc/passwd`) | refused and reported, never used as a path |
| zip bomb | capped per member and in total, refused rather than decompressed |
| output pollution | comments stripped by a real lexer (strings and long brackets respected), result must still compile |
| hostile zip member | path refused and reported; nothing is ever extracted to disk |
| attachment name as a path | collapsed to `input.<allowed ext>`; the name never reaches the filesystem |

Run the bot as a **non-root user** in a container with no inbound ports and no
other secrets in its environment. Nothing here replaces that.

## Three ways to give it a script

| you send | what happens |
|---|---|
| a `.lua`/`.luau`/`.txt` attachment | dumped |
| ``` ```lua … ``` ``` in the message (or a single `inline` span) | dumped; the command word, the prose around it and the fence are not part of the script |
| a link, or a whole `loadstring(game:HttpGet("…"))()` line | fetched, then dumped (`.get` sends it back untouched instead) |
| `.l` as a **reply** to any of the above | same, without uploading twice |

Precedence when a message has several: attachment, then pasted code, then link —
the link is last because it is the only source that leaves the machine. A URL
*inside* the pasted script is never mistaken for a link.

## Links

`.l`, `.luraph`, `.get` and `.detect` accept a URL in the message. Because the bot is
the one making the request, every hop is checked first — a bot that fetches
whatever it is given is a server-side request forgery hole:

| what someone tries | what happens |
|---|---|
| `http://127.0.0.1:8080/admin` | refused: points to a private address |
| `http://169.254.169.254/latest/meta-data/` (cloud credentials) | refused, before any connection |
| `http://[::1]/`, `http://10.x`, `http://192.168.x`, `*.internal`, `*.local` | refused |
| `http://2130706433/`, `http://0x7f000001/`, `http://127.1/` | refused after resolution |
| `http://127.0.0.1.nip.io/` (DNS rebinding) | refused: the resolved address is checked and pinned |
| `file://`, `ftp://`, `data:`, `javascript:` | refused by scheme |
| `http://user:pass@host/x` | refused: credentials in a URL are not fetched |
| redirects | followed by hand, max 3, every hop re-checked |
| a 10 GB response | cut off at the size limit while streaming |
| an image or a video | refused by content type |
| `https://ipinfo.io/json`, `ipify.org`, `ifconfig.me`, `icanhazip.com`, `ip-api.com`, `httpbin.org/ip`, `checkip.amazonaws.com`, `/cdn-cgi/trace` | refused: they exist to report the caller's address |
| `CATLOG_FETCH=off` | no link is fetched at all |
| `CATLOG_FETCH_ALLOW=raw.githubusercontent.com` | only those hosts |
| `CATLOG_FETCH_BLOCK=…` | extra hosts to refuse |

`.get` sends the bytes **exactly** as served — no rewriting, no comments, no
execution. `.l` runs the downloaded script through the engine like any other.

**The address of the machine is still the address of the machine.** A blocklist
cannot cover a service someone sets up themselves, so the only real fix is that
the address is not your home line: run the bot on a VPS, or through WireGuard/Tor.
`docs/SERVER.md` has the three setups and says plainly which part code cannot
solve. Nothing about the caller is written to the log: no hostname, no port, no
IP, no URL.

## A zip, without asking you to unzip it

With `.l`, upload a `.zip` and you get back the CatLog result **plus** the other
scripts inside it, as ordinary attachments. `.luraph` instead lifts only the
selected Luraph entry. Nothing is extracted on the host; archive contents stay
in memory.

* the entry point is `init.lua` / `main.lua` / `index.lua`, else the biggest script;
* only `.lua`, `.luau`, `.txt` are read — a `.png` or a `.md` is listed as skipped, not guessed at;
* members that point outside the archive (`../../etc/passwd`, `/etc/passwd`, `C:/…`) are refused and reported;
* a member over 2 MB, an archive over 6 MB, or more than 40 files: refused by reading the header, never decompressed;
* Discord allows 10 files per message, so the result plus the first 9 files go out; the rest are named in the embed.

## What the output is

The result is what the script did during one run, written back as Luau. Not
every obfuscator can be followed to the end; when CatLog cannot finish, the file
says so instead of pretending otherwise.

## Prometheus / WeAreDevs envlog

Prometheus and WeAreDevs samples run through CatLog's instrumented Luau
runtime. CatLog records only operations observed during that run; it does not
switch to a static source deobfuscator. WeAreDevs' mixed-case, digit-interleaved
private globals are treated as absent environment names, not executor APIs.

## Project links

* Support: https://discord.gg/2aDSEyhcq
* Engine notes: `docs/ENGINE.md`
