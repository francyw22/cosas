# CatLog dynamic envlog

CatLog executes the input once inside its instrumented Luau runtime and emits a
Luau log of operations that actually occurred. It is an environment logger,
not a static source deobfuscator: untaken branches and code that never executes
are not recovered.

## Runtime path

1. `catlog/engine.py` selects the compatibility mode from the input fingerprint.
2. `catlog/harness.py` builds an isolated run around `catlog/catlog.luau`.
3. `catlog/catlog.luau` provides the virtual Roblox/executor environment and
   records calls, property access, writes, filesystem operations and prints.
4. `catlog/traceout.py` turns observed statements into readable Luau. The
   resulting file is comment-cleaned and checked before delivery.

The user's code runs in Luau, not in Python. The executor filesystem is an
in-memory virtual filesystem; it cannot read CatLog's host files. Missing-file
errors omit harness paths because those strings can be observed by code using
`pcall`.

## Prometheus / WeAreDevs compatibility

Prometheus and WeAreDevs samples use the same dynamic execution path. The
WeAreDevs fingerprint enables a narrow compatibility rule: long, generated
mixed-case global names (including digit-interleaved cache names) resolve as
absent globals in a fresh environment instead of truthy API proxies. That
prevents obfuscated type checks from failing on a fake `userdata` value. The
rule is scoped to Prometheus mode so ordinary Roblox/executor globals remain
available.

Filesystem calls such as `listfiles`, `readfile`, `isfile` and `isfolder` are
written into the envlog. Their results reflect only the virtual filesystem
configured for the run. An empty mock filesystem may therefore produce a
successful trace saying that no target files were found; that is not recovery
of a hidden payload.

## Reading a result

A successful envlog contains the run status and statement count followed by the
observed calls. A statement count of zero means the script did not yield an
executable operation for CatLog to record. On a runtime error, CatLog reports
the failure rather than presenting a partial trace as a complete dump. The
trace describes one execution and is not a promise that every branch or
external dependency was exercised.
