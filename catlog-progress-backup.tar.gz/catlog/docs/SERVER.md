# Running the bot so a link cannot point at you

The bot cannot stop someone from pointing a link at a service that echoes the
caller's address — they can always buy a domain. What it can do is make what a
stranger receives worth nothing: **the address must belong to the machine, not
to you.**

Pick one, from easiest to strongest.

## 1. A VPS (any provider) — 5 minutes

The address the world sees is the VPS's, not yours. Run the bot there and a
stranger learns "some VPS in Frankfurt", nothing that leads back to you.

```bash
sudo apt-get update && sudo apt-get install -y python3-venv build-essential cmake git
adduser --system --group catlog            # a non-root user for the bot
sudo -u catlog -i
git clone <your repo> ~/catlog && cd ~/catlog
scripts/build_luau.sh
pip install -r requirements.txt
cp .env.example .env && $EDITOR .env       # DISCORD_TOKEN
python run.py
```

## 2. VPS + WireGuard exit (hides even the datacenter)

If the VPS's own IP is still "yours" in the sense that it is the only thing you
run, route the bot's outbound traffic through a VPN provider:

```bash
sudo apt-get install -y wireguard
# put the provider's config in /etc/wireguard/wg0.conf, then:
sudo systemctl enable --now wg-quick@wg0
# make sure DNS goes through the tunnel too, or the handshake leaks your resolver
resolvectl dns wg0 1.1.1.1
```

The bot's `.get` now leaves from the VPN's address. This is the cheap version of
a proxy.

## 3. Route all the bot's traffic through Tor (strongest, slowest)

```bash
sudo apt-get install -y tor
# /etc/tor/torrc:  SocksPort 9050
sudo systemctl enable --now tor
```

In `.env`:

```dotenv
HTTP_PROXY=socks5h://127.0.0.1:9050
HTTPS_PROXY=socks5h://127.0.0.1:9050
```

Use `socks5h://` and not `socks5://`: the `h` makes the *proxy* resolve the
name, so DNS does not leak the destination — and it also means a hostile
hostname never resolves on your machine. Note that `aiohttp` needs
`aiohttp-socks` for these; without it, use the WireGuard route instead.

Tor exit nodes are blocked by some hosts (GitHub raw is usually fine, some
pastebins are not), and the timeout may need raising.

## 4. Anywhere: a throwaway address

Even on your own home line, none of this matters if the address is not yours:

* **CGNAT** (most home connections in Spain): the public IP is shared with
  hundreds of customers, so it says nothing about you;
* a **dynamic IP**: it changes; the answer is stale by the time anyone looks;
* a **mobile hotspot / tethering** while the bot runs: the address belongs to
  the operator's pool.

## What the bot blocks on its own

`bot/fetch.py`:

| protection | effect |
|---|---|
| private/loopback/link-local/reserved targets | `.get http://192.168.1.1/` and cloud metadata are refused before a socket opens |
| DNS rebinding | the resolved address is validated and **pinned** for the connection |
| known address-echo services | `ipinfo.io`, `ipify.org`, `ifconfig.me`, `icanhazip.com`, `ip-api.com`, `httpbin.org/ip`, `checkip.amazonaws.com`, `/cdn-cgi/trace` … refused by name |
| `CATLOG_FETCH=off` | link fetching disabled entirely |
| `CATLOG_FETCH_ALLOW=raw.githubusercontent.com,github.com` | only those hosts, nothing else |
| `CATLOG_FETCH_BLOCK=…` | extra hostnames to refuse |
| the log | no hostname, no port, no IP, no URL is ever written to the log or to a Discord message |

## The part that is not solvable, said plainly

Anyone who can type a URL into Discord can also put that URL in their own
browser, or in a script on their own machine. If the goal is "find out who runs
this bot", the address is only one way, and it is the one this project can make
uninteresting. Hosting on a VPS you do not otherwise use, with no personal
account attached to it, is the only thing that actually separates the bot from
you. The code cannot do that part.
