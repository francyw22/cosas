# Envlog output and failures

CatLog executes a script in its isolated instrumented Luau runtime and emits
only the operations that occur in that run. It does not statically rebuild
untaken branches or guarantee that external dependencies are available.

A complete result includes the observed statements and run status. If the
runtime fails, the result reports that error instead of presenting the harness
or a traceback as Lua code. A missing or truncated `ENVLOG-BEGIN` /
`ENVLOG-END` block is a logger failure, not a successful dump.

The executor filesystem is virtual and in-memory. File listings and reads are
logged, but only return files explicitly present in that virtual environment;
they never inspect the host filesystem.
