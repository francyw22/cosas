# CatLog — announcements

Ready to paste into Discord. The English block is the one to post if your
server is in English; the Spanish one is the same text. Nothing here promises
more than CatLog does.

---

## English — long version (announcements channel)

```
📜  INTRODUCING CATLOG

CatLog takes an obfuscated Roblox script and gives you back what it does, written
as readable Luau.

HOW IT WORKS
The script is executed once inside a fake environment built to behave like
Roblox — services, instances, events, remotes, HTTP requests. Every call, every
property write, every remote is recorded, and the recording is written back as
code you can read.

WHAT YOU GET
• The result attached as a .lua file
• One comment in it, the banner, and nothing else
• A run status, the time it took, and any payload the script itself built

COMMANDS (prefix is .)
.l        dump a script — attach it, paste it in a code block, reply .l to a
          message that has one, or paste a link. A whole
          loadstring(game:HttpGet("https://…"))() line works too.
.get      fetch the script behind a link and send it back untouched
.detect   tell you which obfuscator was used, without running anything
.help     every command, in two pages
.links    all official links
.support  how to reach a human
.ticket   open a private support ticket

WHAT IT RECOGNISES
Luraph, IronBrew, Prometheus / WeAreDevs, Hercules, Boronide, PSU, Synapse Xen,
MoonSec, MoonVeil, 77fuscator, luaobfuscator.com, wYnFuscate, PS99 / Sirius,
Ibscura, plus generic string-array obfuscation and raw LuaJIT bytecode.

STRAIGHT TALK
A dump is not the original source. You get the paths the script actually took
during that run; a branch that never executed cannot appear. For some
obfuscators the payload is decrypted inside the VM and CatLog cannot see it yet,
and when that happens the file says so instead of pretending.

Your uploads are never written to a public channel, and there is no command in
this bot that can read files, run commands, or show its own code.

Paste a script and try it:   .l
```

---

## English — short version (one screen)

```
📜  CATLOG IS UP

Obfuscated script in, readable Luau out.

.l <file, code or link>   dump it
.detect            name the obfuscator
.help              all commands
.support           talk to a human

It runs the script once in a fake Roblox environment and writes back everything
it did — every call, property, remote and error. One comment in the output (the
banner), nothing else.

Honest limit: a dump shows the paths that ran, not the original source. Some
obfuscators hide their payload in a VM we can't read yet — the result says so
when that happens.
```

---

## English — command card only

```
.l          dump a script (attach, reply to a file, or paste a link)
.get        download the script behind a link, untouched
.detect     which obfuscator is this?
.help       full command list
.links      official links
.support    support server
.ticket     private support ticket
```

---

## Español — versión larga

```
📜  OS PRESENTO CATLOG

CatLog coge un script de Roblox ofuscado y te devuelve lo que hace, escrito en
Luau legible.

CÓMO FUNCIONA
El script se ejecuta una vez dentro de un entorno falso construido para
comportarse como Roblox: servicios, instancias, eventos, remotos, peticiones
HTTP. Se registra cada llamada, cada escritura de propiedad y cada remoto, y ese
registro se escribe de vuelta como código que puedes leer.

QUÉ TE LLEGA
• El resultado adjunto como archivo .lua
• Un solo comentario dentro, el banner, y nada más
• El estado de la ejecución, lo que tardó y los payloads que el propio script construyó

COMANDOS (el prefijo es .)
.l        hace dump de un script — adjúntalo, pégalo en un bloque de código,
          responde .l a un mensaje que lo tenga, o pega un enlace. Una línea
          entera de loadstring(game:HttpGet("https://…"))() también vale.
.get      descarga el script de un enlace y te lo devuelve sin tocarlo
.detect   te dice qué ofuscador se usó, sin ejecutar nada
.help     todos los comandos, en dos páginas
.links    todos los enlaces oficiales
.support  cómo hablar con una persona
.ticket   abre un ticket privado de soporte

QUÉ RECONOCE
Luraph, IronBrew, Prometheus / WeAreDevs, Hercules, Boronide, PSU, Synapse Xen,
MoonSec, MoonVeil, 77fuscator, luaobfuscator.com, wYnFuscate, PS99 / Sirius,
Ibscura, además de ofuscación genérica por array de strings y bytecode LuaJIT
crudo.

SIN HUMO
Un dump no es el código original. Obtienes los caminos que el script recorrió de
verdad en esa ejecución; una rama que no se ejecutó no puede aparecer. En algunos
ofuscadores el payload se descifra dentro de su VM y CatLog todavía no lo ve, y
cuando pasa el archivo lo dice en vez de disimularlo.

Lo que subes no se publica en ningún canal, y este bot no tiene ningún comando
capaz de leer archivos, ejecutar comandos ni mostrar su propio código.

Pega un script y pruébalo:   .l
```

---

## Notes when posting

* Discord caps a message at 2000 characters. Measured: long English 1810, long
  Spanish 1921, short 552, command card 312 — all four fit in one message. If you
  add anything, split before the "WHAT IT RECOGNISES" / "QUÉ RECONOCE" block.
* Don't promise "full source" or "100 % deobfuscation". That is the one thing
  CatLog cannot honestly claim, and it is the first thing someone will test.
* If you want the commands as a pinned message, use the command card — it is
  under 400 characters.
