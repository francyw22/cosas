#!/usr/bin/env python3
"""Start the CatLog bot.

    python run.py

Configuration comes from the environment (see .env.example). Nothing is read
from the command line, so a shell history never contains a secret.

Startup is deliberately noisy about the two things that actually stop this bot
from working — a missing token and missing Luau binaries — and silent about
everything else. A prefix bot that starts "fine" and then cannot answer a single
command is the worst possible outcome, so the checks happen here, before the
gateway connection.
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "catlog"))

from bot.config import Config          # noqa: E402
from bot import main as botmain        # noqa: E402


def load_dotenv() -> None:
    """Minimal .env reader: KEY=VALUE, no expansion, no code execution."""
    path = HERE / ".env"
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def check_luau() -> list[str]:
    """The engine cannot run without its two CLI tools, built for this CPU."""
    try:
        import binpath
    except Exception as exc:                       # noqa: BLE001
        return [f"could not import binpath.py: {exc}"]
    import platform
    problems = []
    for name in ("luau", "luau-compile"):
        path = binpath.tool(name)
        label = os.path.basename(path)
        if not os.path.isfile(path):
            problems.append(f"{label} not found — run scripts/build_luau.sh "
                            f"(or scripts/fetch_luau.sh on x86-64)")
        elif not os.access(path, os.X_OK):
            problems.append(f"{label} is not executable — chmod +x it")
        elif binpath.arch_problem(path):
            problems.append(f"{label} is {binpath.arch_problem(path)} — "
                            f"run scripts/build_luau.sh on this {platform.machine()} machine")
    return problems


def explain_startup_error(error: BaseException) -> None:
    """Turn Discord's bare HTTP errors into one sentence a human can act on."""
    text = str(error)
    if type(error).__name__ == "LoginFailure" or "improper token" in text.lower() \
            or "401" in text or "Unauthorized" in text:
        print(
            "\nDiscord rejected the bot token (401 Unauthorized).\n"
            "  Check DISCORD_TOKEN in .env: it must be the *bot* token from\n"
            "  Developer Portal -> your application -> Bot -> Reset Token.\n"
            "  A client secret, an application id or a revoked token will do this.\n",
            file=sys.stderr)
        return
    if "50001" in text or "4014" in text or "disallowed intents" in text.lower():
        print(
            "\nDiscord refused the connection because of an intent.\n"
            "  Developer Portal -> your application -> Bot -> Privileged Gateway Intents\n"
            "  turn ON: Message Content Intent\n"
            "  (and make sure SERVER MEMBERS is not required by anything else)\n"
            "  then start the bot again. Nothing is wrong with the code.\n", file=sys.stderr)
    elif "4013" in text or "4014" in text or "invalid intent" in text.lower():
        print("\nDiscord refused the intents this bot asked for: enable Message Content "
              "Intent in the Developer Portal.\n", file=sys.stderr)


def main() -> None:
    load_dotenv()
    cfg = Config.from_env()
    logging.basicConfig(
        level=getattr(logging, cfg.log_level, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    if not cfg.token:
        sys.exit("DISCORD_TOKEN is not set. Put it in .env (see .env.example) or the environment.")

    missing = check_luau()
    if missing:
        print("CatLog will start, but `.l` cannot run:", file=sys.stderr)
        for line in missing:
            print(f"  - {line}", file=sys.stderr)
        print("  one command fixes it: scripts/build_luau.sh "
              "(x86-64 without a toolchain: scripts/fetch_luau.sh)\n", file=sys.stderr)

    try:
        asyncio.run(botmain.start(cfg))
    except KeyboardInterrupt:
        print("stopped")
    except Exception as exc:                       # noqa: BLE001
        explain_startup_error(exc)
        raise SystemExit(1) from None               # the sentence above is the message


if __name__ == "__main__":
    main()
