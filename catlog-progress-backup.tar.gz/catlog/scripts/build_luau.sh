#!/bin/sh
# Build the Luau CLI tools on THIS machine and install them where the engine
# looks for them.
#
#   scripts/build_luau.sh
#
# Why a build and not a download: the official releases only ship x86-64
# (luau-ubuntu.zip is x86-64, windows is x86-64, macos is universal). On
# aarch64/arm64 - a Raspberry Pi, an ARM VPS, a Graviton box - there is nothing
# to download, and an x86-64 binary copied from elsewhere dies with
# "Exec format error". Building also lets us apply the one patch the engine
# needs (see the patch step below).
#
# Needs: git, make (or ninja) and a C++ compiler.
set -e

root="$(cd "$(dirname "$0")/.." && pwd)"
dest="$root/.luau-local"
work="${TMPDIR:-/tmp}/catlog-luau-build"
arch="$(uname -m)"
jobs="$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)"

say() { printf '%s\n' "$*"; }

for tool in git; do
    command -v "$tool" >/dev/null 2>&1 || { say "missing $tool"; exit 1; }
done
if ! command -v make >/dev/null 2>&1 && ! command -v ninja >/dev/null 2>&1; then
    say "missing make (or ninja)"; exit 1
fi
if ! command -v cc >/dev/null 2>&1 && ! command -v gcc >/dev/null 2>&1 \
   && ! command -v clang >/dev/null 2>&1 && ! command -v clang++ >/dev/null 2>&1; then
    say "missing a C++ compiler (g++ or clang++)"; exit 1
fi

say "building Luau for $arch into $dest"
rm -rf "$work"
git clone --depth 1 https://github.com/luau-lang/luau.git "$work"
cd "$work"

# ---------------------------------------------------------------------------
# Patch: a Vector3 in Roblox exposes Magnitude/Unit and the arithmetic methods
# through its metatable; stock Luau's vector_index only resolves x/y/z and then
# raises "attempt to index vector with 'Magnitude'". An anti-tamper check that
# reads v.Magnitude or calls v:Dot(w) therefore fails on a stock build, which
# is exactly what makes a host look fake. The patch adds the properties and
# forwards the methods to the vector library (whose argument layout is already
# self-first).
# ---------------------------------------------------------------------------
python3 - "$work/VM/src/lveclib.cpp" <<'PY'
import sys

path = sys.argv[1]
src = open(path, encoding="utf-8").read()
if "Magnitude" in src and "catlog patch" in src:
    print("lveclib.cpp already patched")
    raise SystemExit(0)

if "#include <string.h>" not in src:
    src = src.replace("#include <math.h>", "#include <math.h>\n#include <string.h>", 1)

src = src.replace(
    "static int vector_create(lua_State* L)",
    "// catlog patch\n"
    "static int vector_method(lua_State* L, const char* s, size_t n);\n\n"
    "static int vector_create(lua_State* L)",
    1,
)

old = '''    luaL_error(L, "attempt to index vector with '%s'", name);
}'''
new = '''    // catlog patch: the members Roblox's Vector3 has and stock Luau does not
    if (namelen == 9 && memcmp(name, "Magnitude", 9) == 0)
    {
        float x = v[0], y = v[1], z = v[2];
        lua_pushnumber(L, sqrtf(x * x + y * y + z * z));
        return 1;
    }
    if (namelen == 4 && memcmp(name, "Unit", 4) == 0)
    {
        float x = v[0], y = v[1], z = v[2];
        float m = sqrtf(x * x + y * y + z * z);
        if (m == 0)
            luaL_error(L, "Unit is not a valid member of Vector3 when the magnitude is zero");
        lua_pushvector(L, x / m, y / m, z / m);
        return 1;
    }
    if (vector_method(L, name, namelen))
        return 1;

    luaL_error(L, "attempt to index vector with '%s'", name);
}'''
if old not in src:
    print("could not find vector_index tail; the upstream file changed", file=sys.stderr)
    raise SystemExit(1)
src = src.replace(old, new, 1)

src = src.rstrip() + '''

// catlog patch: Vector3 methods, declared after their implementations.
static int vector_dot(lua_State* L);
static int vector_cross(lua_State* L);
static int vector_angle(lua_State* L);
static int vector_lerp(lua_State* L);
static int vector_abs(lua_State* L);
static int vector_floor(lua_State* L);
static int vector_ceil(lua_State* L);
static int vector_sign(lua_State* L);
static int vector_max(lua_State* L);
static int vector_min(lua_State* L);

static int vector_method(lua_State* L, const char* s, size_t n)
{
    if (n == 3 && memcmp(s, "Dot", 3) == 0) { lua_pushcfunction(L, vector_dot, "Dot"); return 1; }
    if (n == 5 && memcmp(s, "Cross", 5) == 0) { lua_pushcfunction(L, vector_cross, "Cross"); return 1; }
    if (n == 5 && memcmp(s, "Angle", 5) == 0) { lua_pushcfunction(L, vector_angle, "Angle"); return 1; }
    if (n == 4 && memcmp(s, "Lerp", 4) == 0) { lua_pushcfunction(L, vector_lerp, "Lerp"); return 1; }
    if (n == 3 && memcmp(s, "Abs", 3) == 0) { lua_pushcfunction(L, vector_abs, "Abs"); return 1; }
    if (n == 5 && memcmp(s, "Floor", 5) == 0) { lua_pushcfunction(L, vector_floor, "Floor"); return 1; }
    if (n == 4 && memcmp(s, "Ceil", 4) == 0) { lua_pushcfunction(L, vector_ceil, "Ceil"); return 1; }
    if (n == 4 && memcmp(s, "Sign", 4) == 0) { lua_pushcfunction(L, vector_sign, "Sign"); return 1; }
    if (n == 3 && memcmp(s, "Max", 3) == 0) { lua_pushcfunction(L, vector_max, "Max"); return 1; }
    if (n == 3 && memcmp(s, "Min", 3) == 0) { lua_pushcfunction(L, vector_min, "Min"); return 1; }
    return 0;
}
'''
open(path, "w", encoding="utf-8").write(src)
print("lveclib.cpp patched")
PY

# ---------------------------------------------------------------------------
# Patch 2: closure introspection. Roblox's debug library exposes
# getupvalue/setupvalue/getupvalues/getconstants; stock Luau ships only
# info/traceback. The C API underneath (lua_getupvalue/lua_setupvalue) already
# reads and writes real upvalues, C closures included - the library just does
# not expose them. Anti-tamper scripts mutate an upvalue and read it back to
# prove they are being watched (HoneyLUA does exactly this), so without this
# the honest answer is "not supported" and the script stops there.
# ---------------------------------------------------------------------------
python3 - "$work/VM/src/ldblib.cpp" <<'PY2'
import sys

path = sys.argv[1]
src = open(path, encoding="utf-8").read()
if "catlog patch: closure introspection" in src:
    print("ldblib.cpp already patched")
    raise SystemExit(0)

add = """
// catlog patch: closure introspection (see build_luau.sh). Not a model: these
// forward to lua_getupvalue/lua_setupvalue, the same objects the VM uses.
static int db_getupvalue(lua_State* L)
{
    int n = luaL_checkinteger(L, 2);
    const char* name = lua_getupvalue(L, 1, n);
    if (name == NULL)
        return 0;
    lua_pushstring(L, name);
    lua_insert(L, -2);
    return 2;
}

static int db_setupvalue(lua_State* L)
{
    int n = luaL_checkinteger(L, 2);
    lua_settop(L, 3);
    const char* name = lua_setupvalue(L, 1, n);
    if (name == NULL)
    {
        lua_pop(L, 1);
        return 0;
    }
    lua_pushstring(L, name);
    return 1;
}

static int db_getupvalues(lua_State* L)
{
    lua_newtable(L);
    for (int i = 1;; i++)
    {
        const char* name = lua_getupvalue(L, 1, i);
        if (name == NULL)
            break;
        lua_pushstring(L, name);
        lua_rawset(L, -3);
    }
    return 1;
}

static int db_getconstants(lua_State* L)
{
    // a C closure has no constants; an empty table is what Roblox reports too
    luaL_checktype(L, 1, LUA_TFUNCTION);
    lua_createtable(L, 0, 0);
    return 1;
}
"""

old = 'static const luaL_Reg dblib[] = {\n    {"info", db_info},\n    {"traceback", db_traceback},'
new = add + '\nstatic const luaL_Reg dblib[] = {\n    {"info", db_info},\n    {"traceback", db_traceback},\n    {"getupvalue", db_getupvalue},\n    {"setupvalue", db_setupvalue},\n    {"getupvalues", db_getupvalues},\n    {"getconstants", db_getconstants},'
if old not in src:
    print("could not find the debug library table", file=sys.stderr)
    raise SystemExit(1)
src = src.replace(old, new, 1)
open(path, "w", encoding="utf-8").write(src)
print("ldblib.cpp patched")
PY2

# -DLUAU_BUILD_TESTS=OFF keeps the build small and fast; the Luraph lifter
# additionally needs Luau.Ast.CLI (luau-ast) to inspect VM syntax trees.
if command -v cmake >/dev/null 2>&1; then
    cmake -B build -DCMAKE_BUILD_TYPE=Release \
          -DLUAU_BUILD_TESTS=OFF -DLUAU_BUILD_WEB=OFF ${CMAKE_ARGS:-} >/dev/null
    cmake --build build --target Luau.Repl.CLI Luau.Compile.CLI Luau.Ast.CLI -j "$jobs"
else
    say "cmake not found, using the Makefile"
    make -j "$jobs" luau luau-compile luau-ast
fi

mkdir -p "$dest"
found=0
for exe in luau luau-compile luau-ast; do
    for candidate in "build/$exe" "build/CMakeFiles/$exe" "build/$(find build -name "$exe" -type f 2>/dev/null | head -1)" "./$exe"; do
        if [ -f "$candidate" ]; then
            cp "$candidate" "$dest/$exe"
            chmod +x "$dest/$exe"
            found=$((found + 1))
            break
        fi
    done
done
if [ "$found" -ne 3 ]; then
    say "the build finished but luau, luau-compile, or luau-ast were not where expected."
    say "look in $work/build and copy them to $dest"
    exit 1
fi

cd "$root"
rm -rf "$work"
say ""
say "installed:"
"$dest/luau" --version 2>&1 | head -2 || true
say "  $dest/luau"
say "  $dest/luau-compile"
say ""
say "check: python3 run.py   (it now reports the engine as ready)"
