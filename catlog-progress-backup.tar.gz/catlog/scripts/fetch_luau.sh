#!/bin/sh
# Put the Luau CLI tools in catlog/bin/ (they are not committed: 3-8 MB binaries).
#   scripts/fetch_luau.sh              # download the official release
#   scripts/fetch_luau.sh luau.zip     # or use a zip you already have
set -e
arch="$(uname -m)"
case "$arch" in
    x86_64|amd64) ;;
    *)  echo "the official Luau release is x86-64 only; this machine is $arch." >&2
        echo "use scripts/build_luau.sh instead." >&2
        exit 1 ;;
esac
dir="$(cd "$(dirname "$0")/../.luau-local" && pwd)"
mkdir -p "$dir"
if [ -n "$1" ]; then
    unzip -o "$1" -d "$dir"
else
    url="$(curl -fsSL https://api.github.com/repos/luau-lang/luau/releases/latest \
          | grep -o 'https://[^"]*luau-ubuntu.zip' | head -1)"
    [ -n "$url" ] || { echo "could not find the release asset; pass a zip instead" >&2; exit 1; }
    tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
    curl -fsSL "$url" -o "$tmp/luau.zip"
    unzip -o -q "$tmp/luau.zip" -d "$dir"
fi
chmod +x "$dir/luau" "$dir/luau-compile" "$dir/luau-ast" 2>/dev/null || true
rm -f "$dir/luau-analyze"
"$dir/luau" --version || true
