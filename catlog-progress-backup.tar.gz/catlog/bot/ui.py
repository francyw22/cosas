"""Small helpers shared by the views, the commands and the embeds."""
from __future__ import annotations

import discord

BRAND = 0x5865F2          # discord blurple
OK = 0x2ECC71
WARN = 0xE67E22
BAD = 0xE74C3C

LIMITS = {
    "title": 256,
    "field_name": 256,
    "field_value": 1024,
    "description": 4096,
    "footer": 2048,
    "author": 256,
}


def clip(text: str, limit: int, suffix: str = "…") -> str:
    text = "" if text is None else str(text)
    if len(text) <= limit:
        return text
    return text[: max(0, limit - len(suffix))] + suffix


def embed(title: str, description: str = "", *, colour: int = BRAND,
          fields: list[tuple[str, str, bool]] | None = None,
          footer: str | None = None) -> discord.Embed:
    e = discord.Embed(title=clip(title, LIMITS["title"]),
                      description=clip(description, LIMITS["description"]),
                      colour=colour)
    for name, value, inline in fields or []:
        e.add_field(name=clip(name, LIMITS["field_name"]),
                    value=clip(value or "—", LIMITS["field_value"]), inline=inline)
    if footer:
        e.set_footer(text=clip(footer, LIMITS["footer"]))
    return e


def link_lines(links: dict[str, str]) -> str:
    """Markdown list of links, one per line. Empty dict -> empty string."""
    if not links:
        return ""
    return "\n".join(f"• [{label}]({url})" for label, url in links.items())


def human_bytes(n: int) -> str:
    """146791 -> '143.4 KB'. It used to divide twice and print '0.1 KB'."""
    size = float(n)
    for unit in ("B", "KB", "MB"):
        if size < 1024 or unit == "MB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} MB"


def human_seconds(s: float) -> str:
    return f"{s:.1f}s" if s < 60 else f"{s / 60:.1f} min"
