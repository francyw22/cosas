"""Fetch a script from a URL — safely.

A bot that downloads whatever link it is given is a server-side request forgery
hole: `http://127.0.0.1:8080/admin`, `http://169.254.169.254/latest/meta-data/`
(the cloud metadata endpoint, which hands out credentials), `http://[::1]/`,
`http://2130706433/` — all of them make *the bot's host* issue the request from
inside its own network. So every hop is checked before it happens:

* scheme must be http or https; nothing else is even parsed;
* the hostname must not be localhost, *.localhost, *.local, *.internal, or a
  metadata name;
* the name is resolved **here**, and every address it resolves to must be
  globally routable. A private, loopback, link-local, reserved or multicast
  address ends the request before a socket is opened;
* the connection is pinned to the address that was checked (a custom resolver),
  so a DNS answer that changes between the check and the connection - the
  classic rebinding trick - lands on the address we already validated;
* redirects are followed by hand, at most three, and every hop is checked again;
* the body is read in chunks and cut off at the limit, so a 10 GB response
  cannot fill the disk or the memory;
* only text comes back: an image or a video is refused by content type.

Nothing here is a substitute for running the bot in a container without other
secrets; it is the difference between "a link cannot hurt us" and "a link cannot
hurt us yet".
"""
from __future__ import annotations

import asyncio
import os
import ipaddress
import re
import socket
from dataclasses import dataclass
from urllib.parse import urlsplit, urljoin

import aiohttp

MAX_BYTES = 4 * 1024 * 1024
MAX_REDIRECTS = 3
TIMEOUT = 25
USER_AGENT = "CatLog/1.0 (+script fetcher)"

# Services whose whole purpose is to tell you the caller's IP (or geolocate it,
# or log it). Fetching one turns `.get` into "what is my server's address, and
# where is it". The list cannot be complete - anyone can run their own - which
# is why it is combined with the allowlist and the documentation below.
ECHO_HOSTS = {
    "ipinfo.io", "ipify.org", "ifconfig.me", "ifconfig.co", "icanhazip.com",
    "ip-api.com", "ipapi.co", "ipwho.is", "ipwhois.app", "myip.com", "myip.io",
    "api.my-ip.io", "ip.me", "ip.sb", "api.ip.sb", "ipchicken.com", "ipaddress.my",
    "whatismyip.com", "whatismyipaddress.com", "wtfismyip.com", "checkip.amazonaws.com",
    "checkip.dyndns.org", "ipleak.net", "ipleak.org", "dnsleaktest.com",
    "httpbin.org", "postman-echo.com", "ipv4.icanhazip.com", "ipv6.icanhazip.com",
    "geoip.co", "ipgeolocation.io", "db-ip.com", "ipinfo.co", "seeip.org",
    "ident.me", "v4.ident.me", "monip.org", "ipfingerprints.com",
}
ECHO_PATHS = ("/ip", "/json", "/geoip", "/cdn-cgi/trace")   # only for the hosts above

BLOCKED_NAMES = {"localhost", "localhost.localdomain", "ip6-localhost", "metadata",
                 "metadata.google.internal", "instance-data"}
BLOCKED_SUFFIXES = (".localhost", ".local", ".internal", ".localdomain", ".home.arpa")
TEXTUAL_TYPES = ("text/", "application/octet-stream", "application/lua", "application/x-lua",
                 "application/json", "application/xml", "binary/octet-stream")
URL_IN_TEXT = re.compile(r"https?://[^\s<>\"')]+", re.I)


@dataclass
class FetchResult:
    ok: bool
    data: bytes | None = None
    url: str = ""                 # the URL that finally answered
    error: str = ""               # a fixed sentence, safe to show a user
    status: int = 0


def mode() -> str:
    """`on` (default), `off` (no link fetching at all) — from CATLOG_FETCH."""
    return (os.environ.get("CATLOG_FETCH") or "on").strip().lower()


def _env_hosts(name: str) -> list[str]:
    raw = (os.environ.get(name) or "").replace(" ", ",")
    return [h.strip().lower() for h in raw.split(",") if h.strip()]


def _matches(host: str, entries: list[str]) -> bool:
    for entry in entries:
        entry = entry.lstrip("*.").lower()
        if host == entry or host.endswith("." + entry):
            return True
    return False


def find_url(text: str) -> str:
    """The first http(s) URL in a message, or ''."""
    match = URL_IN_TEXT.search(text or "")
    return match.group(0).rstrip(".,;:") if match else ""


def _bad_ip(ip: ipaddress._BaseAddress) -> bool:
    """Any address that is not a public internet address."""
    return not (ip.is_global and not ip.is_multicast and not ip.is_reserved)


def validate_url(url: str) -> str:
    """A fixed sentence describing why this URL may not be fetched, or ''."""
    if mode() == "off":
        return "fetching links is turned off on this bot; attach the file instead"
    try:
        parts = urlsplit(url.strip())
    except ValueError:
        return "that link is not a valid URL"
    if parts.scheme not in ("http", "https"):
        return "only http and https links can be fetched"
    if not parts.hostname:
        return "that link has no host name"
    if parts.username or parts.password:
        return "links with a username or password in them are not fetched"
    host = parts.hostname.lower().rstrip(".")

    allow = _env_hosts("CATLOG_FETCH_ALLOW")
    if allow and not _matches(host, allow):
        return "that link is not on the list of allowed hosts"
    if _matches(host, _env_hosts("CATLOG_FETCH_BLOCK")):
        return "that link is not fetched by this bot"
    if _matches(host, list(ECHO_HOSTS)):
        return "that link looks up this server's address, which the bot will not do"
    if (parts.path or "").startswith("/cdn-cgi/trace"):
        return "that link looks up this server's address, which the bot will not do"

    if host in BLOCKED_NAMES or host.endswith(BLOCKED_SUFFIXES):
        return "that link points to a local address, which this bot will not fetch"
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return ""                                    # a name: checked when resolved
    if _bad_ip(ip):
        return "that link points to a private address, which this bot will not fetch"
    return ""


def _check_addresses(host: str, infos: list) -> str:
    """'' if every resolved address is public, else the reason to refuse."""
    addresses = []
    for info in infos:
        try:
            addresses.append(ipaddress.ip_address(info[4][0].split("%")[0]))
        except (ValueError, IndexError):
            return "that link's host could not be resolved"
    if not addresses:
        return "that link's host could not be resolved"
    if any(_bad_ip(ip) for ip in addresses):
        return "that link resolves to a private address, which this bot will not fetch"
    return ""


async def _resolve(host: str, port: int) -> tuple[list, str]:
    loop = asyncio.get_running_loop()
    try:
        infos = await loop.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError):
        return [], "that link's host could not be resolved"
    return infos, _check_addresses(host, infos)


class _PinnedResolver(aiohttp.abc.AbstractResolver):
    """Resolve only the addresses we already validated, for one host."""

    def __init__(self, host: str, infos: list) -> None:
        self.host = host
        self.entries = []
        for info in infos:
            self.entries.append({
                "hostname": host,
                "host": info[4][0],
                "port": info[4][1],
                "family": info[0],
                "proto": info[2],
                "flags": 0,
            })

    async def resolve(self, host, port=0, family=socket.AF_INET):
        if host != self.host:
            raise OSError("unexpected host")
        return [dict(e, port=port) for e in self.entries]

    async def close(self) -> None:
        return None


def _text_content_type(value: str) -> bool:
    if not value:
        return True
    value = value.split(";")[0].strip().lower()
    return any(value.startswith(prefix) for prefix in TEXTUAL_TYPES)


async def fetch(url: str, *, max_bytes: int = MAX_BYTES, timeout: int = TIMEOUT) -> FetchResult:
    """Download ``url`` with every hop validated. Never raises."""
    current = url.strip()
    for _hop in range(MAX_REDIRECTS + 1):
        problem = validate_url(current)
        if problem:
            return FetchResult(False, error=problem)
        parts = urlsplit(current)
        host = parts.hostname.lower().rstrip(".")
        port = parts.port or (443 if parts.scheme == "https" else 80)
        infos, problem = await _resolve(host, port)
        if problem:
            return FetchResult(False, error=problem)
        connector = aiohttp.TCPConnector(resolver=_PinnedResolver(host, infos))
        try:
            async with aiohttp.ClientSession(
                    connector=connector,
                    timeout=aiohttp.ClientTimeout(total=timeout)) as session:
                async with session.get(current, allow_redirects=False,
                                       headers={"User-Agent": USER_AGENT}) as response:
                    if response.status in (301, 302, 303, 307, 308):
                        location = response.headers.get("Location", "")
                        if not location:
                            return FetchResult(False, error="that link redirected nowhere",
                                               status=response.status)
                        current = urljoin(current, location)
                        continue
                    if response.status >= 400:
                        return FetchResult(False, status=response.status,
                                           error=f"that link answered with HTTP {response.status}")
                    if not _text_content_type(response.headers.get("Content-Type", "")):
                        return FetchResult(False, status=response.status,
                                           error="that link is not a text script")
                    chunks, total = [], 0
                    async for chunk in response.content.iter_chunked(64 * 1024):
                        total += len(chunk)
                        if total > max_bytes:
                            return FetchResult(
                                False, status=response.status,
                                error=f"that link is larger than {max_bytes // (1024 * 1024)} MB")
                        chunks.append(chunk)
                    return FetchResult(True, data=b"".join(chunks), url=current,
                                       status=response.status)
        except asyncio.TimeoutError:
            return FetchResult(False, error="that link took too long to answer")
        except aiohttp.ClientError:
            return FetchResult(False, error="that link could not be reached")
        except (OSError, ValueError):
            return FetchResult(False, error="that link could not be reached")
    return FetchResult(False, error="that link redirected too many times")
