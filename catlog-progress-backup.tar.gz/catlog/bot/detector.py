"""Obfuscator detection, driven by a data file instead of hardcoded guesses.

`fingerprints.json` holds one entry per obfuscator: the regexes that identify
it and the confidence of each. Adding an obfuscator means adding JSON, not
editing code.

Why the corpus fingerprinting (tools/derive_signatures.py) is not the whole
story: the big families (IronBrew2, Prometheus, Luraph) generate the VM
themselves, so their *identifiers* are random per build and look nearly
identical across families — a token-counting signature collapses them. What
does separate them is the banner comment and the VM prologue, so those are
what the rules below use, plus body markers for the families whose body is
stable (Boronide, SynapseXen, MoonSec, PSU, 77fuscator, luaobfuscator).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

FP_PATH = Path(__file__).with_name("fingerprints.json")
HEAD_BYTES = 128 * 1024


@dataclass
class Hit:
    obfuscator: str
    display: str
    weight: float
    rule: str
    output: str


def load_fingerprints(path: Path | None = None) -> dict:
    return json.loads((path or FP_PATH).read_text())


_FP = load_fingerprints()
_COMPILED: dict[str, list[tuple[str, float, re.Pattern]]] = {}
for _fam, _entry in _FP["families"].items():
    _rules = []
    for _p in _entry["patterns"]:
        flags = re.IGNORECASE | re.MULTILINE
        if _p["id"] in {"bytecode", "luraph_vm_shape", "ironbrew2_vm"}:
            flags = re.MULTILINE
        _rules.append((_p["id"], float(_p["weight"]), re.compile(_p["regex"], flags)))
    _COMPILED[_fam] = _rules


def detect(src: str) -> list[Hit]:
    """Every obfuscator that fires, most confident first. Never raises."""
    head = src[:HEAD_BYTES]
    hits: list[Hit] = []
    for fam, rules in _COMPILED.items():
        entry = _FP["families"][fam]
        best_rule: tuple[str, float] | None = None
        for rule_id, weight, rx in rules:
            try:
                if rx.search(head):
                    if best_rule is None or weight > best_rule[1]:
                        best_rule = (rule_id, weight)
            except Exception:
                continue
        if best_rule:
            hits.append(Hit(fam, entry["display"], best_rule[1], best_rule[0],
                            entry["output"]))
    hits.sort(key=lambda h: h.weight, reverse=True)
    return hits


def best(src: str) -> tuple[Hit | None, list[Hit]]:
    hits = detect(src)
    return (hits[0] if hits else None), hits




def summary() -> list[tuple[str, str, str]]:
    """(obfuscator, display, output) for every obfuscator known."""
    return [(fam, e["display"], e["output"]) for fam, e in _FP["families"].items()]
