"""CatLog configuration, loaded once from the environment.

Nothing here comes from user input: every value is a constant or an env var
read at boot. The bot refuses to start when a required value is missing or
malformed rather than running half-configured.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _int(name: str, default: int, low: int = 1, high: int = 10 ** 6) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise SystemExit(f"{name} must be an integer, got {raw!r}")
    if not low <= value <= high:
        raise SystemExit(f"{name} must be between {low} and {high}, got {value}")
    return value


def _csv(name: str) -> tuple[str, ...]:
    raw = os.environ.get(name, "")
    return tuple(p.strip() for p in raw.split(",") if p.strip())


@dataclass(frozen=True)
class Config:
    token: str
    guild_id: int | None
    support_server: str
    website: str
    source_repo: str
    docs_url: str
    max_input_bytes: int
    max_output_bytes: int
    job_timeout: int
    concurrency: int
    cooldown_seconds: int
    log_level: str
    extra_links: tuple[str, ...] = field(default_factory=tuple)

    @classmethod
    def from_env(cls) -> "Config":
        token = os.environ.get("DISCORD_TOKEN", "").strip()
        if not token:
            raise SystemExit(
                "DISCORD_TOKEN is not set. Put it in .env (see .env.example) or the environment."
            )
        guild = os.environ.get("GUILD_ID", "").strip()
        return cls(
            token=token,
            guild_id=_int("GUILD_ID", 0, 0, 10 ** 20) or None if guild else None,
            support_server=os.environ.get("SUPPORT_SERVER", "").strip(),
            website=os.environ.get("WEBSITE", "").strip(),
            source_repo=os.environ.get("SOURCE_REPO", "").strip(),
            docs_url=os.environ.get("DOCS_URL", "").strip(),
            max_input_bytes=_int("MAX_INPUT_BYTES", 4 * 1024 * 1024),
            max_output_bytes=_int("MAX_OUTPUT_BYTES", 8 * 1024 * 1024),
            job_timeout=_int("JOB_TIMEOUT", 180, 10, 1800),
            concurrency=_int("CONCURRENCY", 2, 1, 16),
            cooldown_seconds=_int("COOLDOWN_SECONDS", 20, 0, 3600),
            log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
            extra_links=_csv("EXTRA_LINKS"),
        )

    def links(self) -> dict[str, str]:
        """Every public link the bot may show. Empty values are dropped."""
        named = {
            "Support server": self.support_server,
            "Website": self.website,
            "Source code": self.source_repo,
            "Documentation": self.docs_url,
        }
        named.update({f"Link {i}": url for i, url in enumerate(self.extra_links, 1)})
        return {label: url for label, url in named.items() if url}
