"""Dependency-preserving chunking of an oversize Luau source.

A large protected script is usually one giant top-level expression (the VM
object). Blindly splitting at N lines would break strings and land in the
middle of expressions, so the splitter tracks:

  * string state (``'``, ``"``, ``[[``, ``[==[``, escapes)
  * comment state (``--``, ``--[[``) so no cut lands inside either
  * bracket depth ((), {}, []) relative to the cut position

A cut is only allowed at a newline where all three say "safe": not in a
string/comment, and depth is 0 or small. If no safe cut exists near the limit
the chunk is allowed to grow instead of producing broken Luau.
"""
from __future__ import annotations

QUOTE, LONG, LINE_COMMENT, BLOCK_COMMENT, CODE = range(5)


def _long_bracket_at(src: str, i: int) -> tuple[int, int] | None:
    """If ``src[i:]`` opens a long bracket (``[[`` / ``[=[``), return (level, end)."""
    if i >= len(src) or src[i] != "[":
        return None
    j = i + 1
    level = 0
    while j < len(src) and src[j] == "=":
        level += 1
        j += 1
    if j < len(src) and src[j] == "[":
        return level, j + 1
    return None


def split_safe(src: str, limit: int) -> list[str]:
    """Split ``src`` into chunks of at most ~``limit`` chars at safe points."""
    if limit <= 0 or len(src) <= limit:
        return [src]

    chunks: list[str] = []
    start = 0
    state = CODE
    depth = 0
    i = 0
    quote = ""
    long_close = ""
    last_safe = -1  # index just past a newline where a cut is allowed

    n = len(src)
    while i < n:
        # The cut check has to happen on every path through the loop, otherwise
        # a script that is one long string or one long comment (exactly the
        # shape of a protected script) never reaches it.
        if i - start > limit and last_safe > start:
            chunks.append(src[start:last_safe])
            start = last_safe
            last_safe = -1

        c = src[i]

        if state == CODE:
            if c == "-" and src.startswith("--", i):
                lb = _long_bracket_at(src, i + 2)
                if lb:
                    level, after = lb
                    state = BLOCK_COMMENT
                    long_close = "]" + "=" * level + "]"
                    i = after
                    continue
                state = LINE_COMMENT
                i += 2
                continue
            if c in "'\"":
                state = QUOTE
                quote = c
                i += 1
                continue
            lb = _long_bracket_at(src, i)
            if lb:
                level, after = lb
                state = LONG
                long_close = "]" + "=" * level + "]"
                i = after
                continue
            if c in "({[":
                depth += 1
            elif c in ")}]":
                depth = max(0, depth - 1)
            elif c == "\n":
                if depth <= 1:
                    last_safe = i + 1
            i += 1
            continue

        if state == QUOTE:
            if c == "\\":
                i += 2
                continue
            if c == quote:
                state = CODE
            elif c == "\n":  # unterminated: the source was already broken
                state = CODE
            i += 1
            continue

        if state == LINE_COMMENT:
            if c == "\n":
                state = CODE
            i += 1
            continue

        # LONG / BLOCK_COMMENT
        if src.startswith(long_close, i):
            i += len(long_close)
            state = CODE
            continue
        i += 1

    if start < n:
        chunks.append(src[start:])
    return chunks


def split_by_lines(src: str, max_lines: int) -> list[str]:
    """Last-resort splitter used when the safe splitter cannot help."""
    out, cur, count = [], [], 0
    for line in src.splitlines(keepends=True):
        cur.append(line)
        count += 1
        if count >= max_lines:
            out.append("".join(cur))
            cur, count = [], 0
    if cur:
        out.append("".join(cur))
    return out or [src]
