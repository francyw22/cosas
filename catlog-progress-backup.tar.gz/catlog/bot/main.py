"""CatLog Discord bot — prefix commands only (no slash commands).

Commands
--------
``.l``      run CatLog on an attached script **or** on a link in the message
``.luraph``  run the bundled Luraph source lifter (v14.7–14.9 / v15.0–15.1)
``.get``    fetch a script from a link and send it back, untouched
``.detect``  (with an attachment) name the obfuscator, nothing is executed
``.links``   every official link
``.support`` open a private support ticket (modal) plus the support link
``.help``    commands and how to reach a human (two pages)

Security rules enforced here
----------------------------
* Child processes are limited to the known CatLog/Luraph engines and started
  with argument lists in ``runner.py``. No shell or user-built command is used.
* Nothing in this package reads or returns the bot token, the environment, the
  working tree, or this file. There is no eval/exec/shell/cat/ls command, on
  purpose, and adding one would be the vulnerability.
* Every error shown to a user is a fixed sentence. Tracebacks go to the log,
  never to Discord.
* One job per user at a time, a global concurrency cap, and a cooldown.
"""
from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import re
import time

import sys
from pathlib import Path

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from catlog.redact import clean_output  # noqa: E402

from . import ui, views  # noqa: E402
from .archive import is_zip, read_zip  # noqa: E402
from .chunker import split_safe  # noqa: E402
from .code import extract_code, has_code  # noqa: E402
from .fetch import fetch, find_url  # noqa: E402
from .config import Config
from .detector import best as detect_obfuscator
from .runner import (JobResult, engine_available, engine_problem, luraph_problem,
                     run_job, run_luraph_job)

LOG = logging.getLogger("catlog.bot")

ALLOWED = {".lua", ".luau", ".txt", ".zip"}
PART_LIMIT = 6 * 1024 * 1024   # Discord refuses anything much bigger
MAX_ATTACHMENT_BYTES = 4 * 1024 * 1024


def build_intents() -> discord.Intents:
    """The intents this bot actually needs — and nothing else.

    ``Intents.default()`` leaves **message_content** off, and a prefix bot with
    that off never sees a command: Discord sends empty content and the command
    silently does not exist. That is why it is turned on explicitly here. It has
    to be enabled in the Developer Portal as well (Bot -> Message Content
    Intent); if it is not, Discord refuses the connection and ``run.py`` explains
    exactly that instead of dumping a traceback.

    Nothing else is requested: no members, no presences, no reactions. The bot
    reads messages in the channels it is allowed to read and answers them.
    """
    intents = discord.Intents.default()
    intents.message_content = True      # required for prefix commands
    intents.guild_reactions = False     # buttons, not reactions
    intents.voice_states = False        # no voice support, by design
    return intents


def silence_voice_warnings() -> None:
    """Stop discord.py from advertising a feature this bot does not have.

    discord.py 2.7 warns at client construction that PyNaCl/davey are missing
    and "voice will NOT be supported". CatLog has no voice code at all — no
    ``connect``, no audio, no ``VoiceClient`` — so the warning is noise about a
    feature that was never offered. The flags exist for exactly this; voice
    channels still raise a clear RuntimeError if anything ever tries to use them.
    """
    discord.VoiceClient.warn_nacl = False
    discord.VoiceClient.warn_dave = False


class CatLogBot(commands.Bot):
    def __init__(self, cfg: Config) -> None:
        silence_voice_warnings()
        super().__init__(command_prefix=".", intents=build_intents(),
                         help_command=None, allowed_mentions=None)
        self.cfg = cfg
        self.sem = asyncio.Semaphore(cfg.concurrency)
        self.busy: set[int] = set()
        self.cooldown: dict[int, float] = {}
        self.links = cfg.links()

    async def on_ready(self) -> None:
        LOG.info("logged in as %s (%s)", self.user, getattr(self.user, "id", "?"))
        if not self.intents.message_content:
            LOG.error("message_content intent is off: prefix commands will not work")
        await self.change_presence(activity=discord.Activity(
            type=discord.ActivityType.watching, name="obfuscated scripts · .help"))

    async def on_command_error(self, ctx: commands.Context, error: Exception) -> None:
        if isinstance(error, commands.CommandNotFound):
            return
        LOG.warning("command error: %s", type(error).__name__)
        await ctx.reply(embed=ui.embed("That did not work",
                                       "Something went wrong on my side. Try again, and if it "
                                       "keeps failing use `.support`.", colour=ui.BAD),
                        mention_author=False)

    # -- guards ------------------------------------------------------------
    def check_user(self, user_id: int) -> str | None:
        now = time.monotonic()
        if user_id in self.busy:
            return "You already have a job running. Wait for it to finish."
        last = self.cooldown.get(user_id, 0.0)
        if self.cfg.cooldown_seconds and now - last < self.cfg.cooldown_seconds:
            wait = int(self.cfg.cooldown_seconds - (now - last)) + 1
            return f"Cooldown: try again in {wait}s."
        return None


bot: CatLogBot = None  # type: ignore[assignment]


def _get_bot() -> CatLogBot:
    return bot


def _attachment_of(ctx: commands.Context) -> discord.Attachment | None:
    """The attachment to work on: this message's, or the one you replied to."""
    if ctx.message.attachments:
        return ctx.message.attachments[0]
    replied = getattr(ctx.message, "reference", None)
    resolved = getattr(replied, "resolved", None) if replied else None
    files = getattr(resolved, "attachments", None) or []
    return files[0] if files else None


async def _source_of(ctx: commands.Context) -> tuple[bytes | None, str, str]:
    """(bytes, name, error) from an attachment, pasted code, or a link.

    In that order: an attachment is unambiguous, pasted code is what the person
    clearly wants dumped, and a link is the one source that leaves the machine,
    so it goes last. The URL is searched for in the text *outside* the code
    block, so a script that itself contains a URL is never mistaken for a link.
    """
    attachment = _attachment_of(ctx)
    if attachment is not None:
        data = await _download(attachment)
        if data is None:
            return None, attachment.filename, "I cannot read that file"
        return data, attachment.filename, ""
    pasted = extract_code(ctx.message.content, ".")
    if pasted:
        return pasted.encode("utf-8"), "pasted.lua", ""
    url = find_url(_strip_code(ctx.message.content))
    if not url:
        return None, "", "nothing to work on"
    result = await fetch(url, max_bytes=MAX_ATTACHMENT_BYTES)
    if not result.ok or result.data is None:
        return None, url, result.error or "that link could not be fetched"
    name = url.rstrip("/").rsplit("/", 1)[-1] or "link.lua"
    return result.data, name, ""


def _luraph_plugin(source: str) -> tuple[str | None, str | None]:
    """Return the supported bundled lifter and displayed version, if identified."""
    match = re.search(
        r"Luraph Obfuscator v(\d+)(?:\.(\d+))?", source[:1000], re.IGNORECASE)
    if not match:
        return None, None
    major = int(match.group(1))
    minor = int(match.group(2) or 0)
    if major == 14 and minor in {7, 8, 9}:
        return "luraph_v14", f"v14.{minor} (experimental)"
    if major == 15 and minor in {0, 1}:
        return "luraph_v15", f"v15.{minor}"
    return None, f"v{major}.{minor}"


def _strip_code(content: str) -> str:
    """The message without its code blocks, so a URL inside the script is not a link."""
    return extract_code(content, ".") and content.split("```")[0] or content


async def _download(attachment: discord.Attachment) -> bytes | None:
    suffix = "." + attachment.filename.rsplit(".", 1)[-1].lower() if "." in attachment.filename else ""
    if suffix not in ALLOWED:
        return None
    if attachment.size > MAX_ATTACHMENT_BYTES:
        return None
    return await attachment.read()


def _result_files(payload: bytes, filename: str = "catlog_result.lua") -> list[discord.File]:
    """One file, or several **whole** ones if the result is too big to upload.

    Splitting is done at a safe point by ``chunker``: never inside a string, a
    long bracket or a comment. Parts are named ``part1..N`` so the order is
    obvious, and each part is plain text you can concatenate back together.
    """
    if len(payload) <= PART_LIMIT:
        return [discord.File(fp=io.BytesIO(payload), filename=filename)]
    parts = split_safe(payload.decode("utf-8", "replace"), PART_LIMIT)
    stem = filename.rsplit(".", 1)[0]
    return [discord.File(fp=io.BytesIO(part.encode("utf-8")),
                         filename=f"{stem}_part{i + 1}.lua")
            for i, part in enumerate(parts)]


def _preview_text(payload: bytes) -> str:
    """A short code preview to place immediately above the uploaded dump."""
    lines = payload.decode("utf-8", "replace").splitlines()[:3]
    if not lines:
        return ""
    # Discord's message limit is 2000 chars; clipping each preview line keeps
    # the three-line preview well below it even for minified dumps.
    lines = [line if len(line) <= 500 else line[:497] + "..." for line in lines]
    return "```lua\n" + "\n".join(lines) + "\n```"


def _result_embed(result: JobResult, source_name: str, cfg: Config) -> discord.Embed:
    colour = ui.OK if result.ok and result.status.startswith("finished") else ui.WARN
    fields = [
        ("Run status", result.status or "unknown", False),
        ("Time", ui.human_seconds(result.seconds), True),
        ("Output", ui.human_bytes(len(result.output or b"")), True),
    ]
    if result.recovered:
        fields.append(("Recovered payloads",
                       ", ".join(f"`{n}` ({ui.human_bytes(len(d))})" for n, d in result.recovered[:6]),
                       False))
    return ui.embed(
        "CatLog finished" if result.ok else "CatLog could not finish",
        f"Input: `{source_name}`" + ("\nThe result is attached." if result.ok else ""),
        colour=colour, fields=fields,
        footer="Powered by CatLog · .help for commands")


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------


def register(b: CatLogBot) -> None:
    global bot
    bot = b

    @b.command(name="l")
    async def dump(ctx: commands.Context) -> None:
        """Dump an obfuscated script in a fake environment that tries to be as Roblox as possible."""
        if (_attachment_of(ctx) is None and not find_url(ctx.message.content)
                and not has_code(ctx.message.content)):
            await ctx.reply(embed=ui.embed(
                "Attach a file, paste the code, or send a link",
                "Use `.l` with the script attached, pasted inside a code block, as a "
                "reply to a message that has one, or with a link — including a whole "
                "`loadstring(game:HttpGet(...))()` line.",
                fields=[("Links", ui.link_lines(b.links) or "—", False)]))
            return
        refusal = b.check_user(ctx.author.id)
        if refusal:
            await ctx.reply(embed=ui.embed("Not right now", refusal, colour=ui.WARN))
            return
        problem = engine_problem()
        if problem:
            # the reason is about THIS host, never about the user's file
            LOG.error("engine unusable: %s", problem)
            await ctx.reply(embed=ui.embed(
                "Engine unavailable", f"CatLog cannot run right now: {problem}. "
                "This is a problem on the bot's side, not with your file.",
                colour=ui.BAD))
            return
        data, file_name, problem = await _source_of(ctx)
        if data is None:
            await ctx.reply(embed=ui.embed("I cannot use that", problem, colour=ui.WARN))
            return

        # A zip is opened here, in memory, and its files are handed back to you
        # as ordinary attachments. Nothing is extracted to disk.
        source, source_name, extras, skipped = data, file_name, [], []
        if is_zip(data):
            archive = read_zip(data)
            skipped = archive.skipped
            main_entry = archive.pick_main()
            if main_entry is None:
                await ctx.reply(embed=ui.embed(
                    "That zip has no script in it",
                    "I look for `.lua`, `.luau` and `.txt` inside, and I will not "
                    "follow paths that point outside the archive.",
                    colour=ui.WARN,
                    fields=[("Skipped", "\n".join(f"• {s}" for s in skipped[:8]) or "—", False)]))
                return
            source = main_entry.text.encode("utf-8")
            source_name = main_entry.name
            extras = archive.extras(main_entry)

        b.busy.add(ctx.author.id)
        try:
            async with b.sem:
                thinking = await ctx.reply(embed=ui.embed(
                    "Running CatLog…", f"`{source_name}` · "
                    f"{ui.human_bytes(len(source))} · usually a few seconds."))
                result = await run_job(source, timeout=b.cfg.job_timeout,
                                      max_output=b.cfg.max_output_bytes,
                                      name=source_name if "." in source_name else "input.lua")
                payload = result.output
                if payload:
                    try:
                        payload = clean_output(payload.decode("utf-8", "replace")).encode("utf-8")
                    except Exception:                      # noqa: BLE001
                        LOG.warning("could not strip comments; sending as-is")
                embed = _result_embed(result, source_name, b.cfg)
                if extras:
                    embed.add_field(
                        name="From the same zip",
                        value=ui.clip("\n".join(f"• `{n}`" for n, _ in extras), 1024),
                        inline=False)
                if skipped:
                    embed.add_field(
                        name="Not read",
                        value=ui.clip("\n".join(f"• {s}" for s in skipped[:6]), 1024),
                        inline=False)
                if payload:
                    files = _result_files(payload)
                    # Discord allows 10 files per message: the result plus the rest
                    # of the archive, untouched, so nothing is lost and no unzip
                    # step is needed on your side.
                    for name, blob in extras[:9]:
                        files.append(discord.File(fp=io.BytesIO(blob), filename=name))
                    note = []
                    if len(files) > 1:
                        note.append(f"the result is large, so it is in {len(files)} parts")
                    if extras:
                        note.append(f"plus {len(extras[:9])} other file(s) from the zip")
                    content = _preview_text(payload)
                    if note:
                        content = (content + "\n\n" if content else "") + "Uploaded: " + ", ".join(note) + "."
                    await ctx.reply(
                        content=content or None,
                        files=files,
                        view=views.ResultView(owner_id=ctx.author.id, result_bytes=payload,
                                              output_name="catlog_result.lua",
                                              status=result.status, seconds=result.seconds,
                                              links=b.links))
                    if result.ok:
                        # On success, the preview + attachment replaces the
                        # redundant "CatLog finished" embed.
                        await thinking.delete()
                    else:
                        await thinking.edit(embed=embed)
                else:
                    await thinking.edit(embed=embed)
        finally:
            b.busy.discard(ctx.author.id)
            b.cooldown[ctx.author.id] = time.monotonic()

    @b.command(name="luraph")
    async def luraph(ctx: commands.Context) -> None:
        """Run only the bundled Luraph source lifter; never substitute a behavior trace."""
        data, file_name, problem = await _source_of(ctx)
        if data is None:
            await ctx.reply(embed=ui.embed(
                "Attach a Luraph script",
                "Use `.luraph` with a `.lua`/`.luau` file, pasted code, a zip containing a script, "
                "a reply to a message with one, or a direct link.", colour=ui.WARN))
            return
        source = data
        source_name = file_name
        if is_zip(data):
            archive = read_zip(data)
            main_entry = archive.pick_main()
            if main_entry is None:
                await ctx.reply(embed=ui.embed(
                    "That zip has no script in it",
                    "I look for `.lua`, `.luau` and `.txt` inside; no files are extracted to disk.",
                    colour=ui.WARN))
                return
            source = main_entry.text.encode("utf-8")
            source_name = main_entry.name

        plugin, version = _luraph_plugin(source.decode("latin-1"))
        if plugin is None:
            if version is None:
                detail = "I could not identify a Luraph version banner in the file."
            else:
                detail = f"`{version}` is not in the bundled source-lifter range."
            await ctx.reply(embed=ui.embed(
                "Unsupported Luraph version",
                detail + " Supported routes are v14.7–v14.9 (experimental) and v15.0–v15.1. "
                "Use `.l` if you want a behavior trace instead.", colour=ui.WARN))
            return
        refusal = b.check_user(ctx.author.id)
        if refusal:
            await ctx.reply(embed=ui.embed("Not right now", refusal, colour=ui.WARN))
            return
        problem = luraph_problem()
        if problem:
            await ctx.reply(embed=ui.embed(
                "Luraph lifter unavailable", f"The bot is missing a local prerequisite: {problem}.",
                colour=ui.BAD))
            return

        b.busy.add(ctx.author.id)
        try:
            async with b.sem:
                thinking = await ctx.reply(embed=ui.embed(
                    "Deobfuscating Luraph…", f"`{source_name}` · {version} · "
                    "source lift only; this may take a while."))
                result = await run_luraph_job(
                    source, plugin=plugin, timeout=b.cfg.job_timeout,
                    max_output=b.cfg.max_output_bytes,
                    name=source_name if "." in source_name else "input.lua")
                if not result.ok or not result.output:
                    await thinking.edit(embed=ui.embed(
                        "No source lift", result.status or
                        "The Luraph source lifter could not recover this sample. "
                        "No behavior trace is being presented as deobfuscated source.",
                        colour=ui.WARN,
                        fields=[("Version", version, True),
                                ("Time", ui.human_seconds(result.seconds), True)]))
                    return
                output_name = "luraph_deobfuscated.lua"
                files = _result_files(result.output, output_name)
                note = (f"The source lift finished for {version}. Output is split into "
                        f"{len(files)} parts." if len(files) > 1 else
                        f"Source lift finished for {version}.")
                await ctx.reply(
                    content=_preview_text(result.output) + "\n\n" + note,
                    files=files,
                    view=views.ResultView(owner_id=ctx.author.id,
                                          result_bytes=result.output,
                                          output_name=output_name,
                                          status=result.status,
                                          seconds=result.seconds,
                                          links=b.links))
                await thinking.delete()
        finally:
            b.busy.discard(ctx.author.id)
            b.cooldown[ctx.author.id] = time.monotonic()

    @b.command(name="detect")
    async def detect(ctx: commands.Context) -> None:
        """Name the obfuscator used, without running anything."""
        data, file_name, problem = await _source_of(ctx)
        if data is None:
            await ctx.reply(embed=ui.embed(
                "Nothing to look at",
                "Use `.detect` with a script attached, pasted in a code block, "
                "a reply to one, or a link: "
                + (problem or "nothing was found"), colour=ui.WARN))
            return
        text = data.decode("utf-8", "replace")
        if is_zip(data):
            archive = read_zip(data)
            main_entry = archive.pick_main()
            if main_entry is None:
                await ctx.reply(embed=ui.embed("That zip has no script in it",
                                               "Nothing to identify.", colour=ui.WARN))
                return
            text = main_entry.text
            file_name = main_entry.name
        top, hits = detect_obfuscator(text)
        fields = [("Obfuscator", top.display if top else "unknown", True),
                  ("Confidence", f"{top.weight:.0%}" if top else "—", True),
                  ("SHA-256", f"`{hashlib.sha256(data).hexdigest()[:32]}`", False)]
        if len(hits) > 1:
            fields.append(("Could also be",
                           "\n".join(f"• {h.display} ({h.weight:.0%})" for h in hits[1:5]), False))
        await ctx.reply(embed=ui.embed(
            "Detection", f"`{file_name}`" +
            (" — read from inside the zip" if is_zip(data) else ""),
            fields=fields))

    @b.command(name="help")
    async def help_cmd(ctx: commands.Context) -> None:
        view = views.HelpView(prefix_hint=".", links=b.links)
        await ctx.reply(embed=view.page_embed(), view=view)

    @b.command(name="links")
    async def links_cmd(ctx: commands.Context) -> None:
        await ctx.reply(embed=ui.embed("Links", ui.link_lines(b.links) or "—"))

    @b.command(name="support")
    async def support(ctx: commands.Context) -> None:
        await ctx.reply(embed=views.support_embed(b.links))

    @b.command(name="ticket")
    async def ticket(ctx: commands.Context) -> None:
        await ctx.send_modal(views.SupportModal(b.links, status=""))

    @b.command(name="get")
    async def get_cmd(ctx: commands.Context) -> None:
        """Fetch the script behind a link and send it back untouched."""
        url = find_url(_strip_code(ctx.message.content)) or find_url(ctx.message.content)
        if not url:
            await ctx.reply(embed=ui.embed(
                "Paste a link",
                "Use `.get` with an http(s) link in the message. "
                "It sends you the file exactly as the server gave it.",
                fields=[("Links", ui.link_lines(b.links) or "—", False)]))
            return
        refusal = b.check_user(ctx.author.id)
        if refusal:
            await ctx.reply(embed=ui.embed("Not right now", refusal, colour=ui.WARN))
            return
        b.busy.add(ctx.author.id)
        try:
            async with b.sem:
                result = await fetch(url, max_bytes=b.cfg.max_input_bytes)
                if not result.ok or result.data is None:
                    await ctx.reply(embed=ui.embed("I could not fetch that", result.error,
                                                   colour=ui.WARN))
                    return
                name = (result.url.rstrip("/").rsplit("/", 1)[-1] or "script.lua").split("?")[0]
                await ctx.reply(
                    embed=ui.embed("Fetched", f"`{ui.clip(name, 200)}` · "
                                   f"{ui.human_bytes(len(result.data))}",
                                   footer="Sent exactly as received · .l to run it through CatLog"),
                    file=discord.File(fp=io.BytesIO(result.data), filename=name[:80]))
        finally:
            b.busy.discard(ctx.author.id)
            b.cooldown[ctx.author.id] = time.monotonic()

async def start(cfg: Config) -> None:
    b = CatLogBot(cfg)
    register(b)
    await b.start(cfg.token)
