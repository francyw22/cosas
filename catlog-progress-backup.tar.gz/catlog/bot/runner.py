"""CatLog job runner: known engines, validated argv, and throwaway workdirs.

No shell, no user-built command, and no user-controlled filesystem path.
"""
from __future__ import annotations

import asyncio
import os
import re
import shutil
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

import logging

LOG = logging.getLogger("catlog.runner")

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent / "catlog" / "deob.py"
LURAPH_DRIVER = HERE.parent / "catlog" / "luraph" / "deob.js"
LURAPH_PLUGIN = LURAPH_DRIVER.parent


# Anything that looks like a host detail. A status line is shown to Discord
# users, so a path, a traceback or an errno must never survive into it.
_LEAK = re.compile(r"(Traceback|File \"|/home/|/usr/|/tmp/|/root/|\\|Errno|"
                   r"[A-Za-z]:\\\\|<module>|line \d+, in )")


def redact(text: str, *, limit: int = 160) -> str:
    """A status line safe to publish: no paths, no tracebacks, no errno soup."""
    first = next((ln.strip() for ln in (text or "").splitlines() if ln.strip()), "")
    first = re.sub(r"^\[\*\]\s*", "", first)        # the engine's own marker
    if not first or _LEAK.search(first):
        return ""
    return first[:limit]


class EngineMissing(RuntimeError):
    """The engine is not where it should be (a deployment mistake, not a user error)."""


@dataclass
class JobResult:
    ok: bool
    status: str
    output: bytes | None
    output_name: str
    recovered: list[tuple[str, bytes]]
    seconds: float


def _engine_cmd(input_path: Path, output_path: Path, timeout: int, recover: bool) -> list[str]:
    if not ENGINE.is_file():
        raise EngineMissing(f"engine not found at {ENGINE}")
    cmd = [sys.executable, str(ENGINE), str(input_path), "-o", str(output_path),
           "--timeout", str(timeout)]
    if recover:
        cmd.append("--recover")
    return cmd


def _read_recovered(workdir: Path) -> list[tuple[str, bytes]]:
    folder = workdir / "recovered"
    if not folder.is_dir():
        return []
    out = []
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in (".bin", ".lua", ".txt"):
            out.append((path.name, path.read_bytes()))
    return out


async def run_job(source: bytes, *, timeout: int = 180, recover: bool = True,
                  max_output: int = 8 * 1024 * 1024, name: str = "input.lua") -> JobResult:
    """Run CatLog on ``source`` inside a throwaway directory.

    The directory is removed **before** this function returns. That matters:
    a ``finally`` that deletes while the result is still an open file would
    close the bytes under ``discord.File`` and the upload would fail. So the
    bytes are read into memory first, then the directory dies.
    """
    import time

    started = time.monotonic()
    workdir = Path(tempfile.mkdtemp(prefix="catlog_job_"))
    try:
        safe_name = _safe_name(name)
        input_path = workdir / safe_name
        input_path.write_bytes(source)
        output_path = workdir / "result.lua"
        cmd = _engine_cmd(input_path, output_path, timeout, recover)
        env = dict(os.environ)
        env.pop("DISCORD_TOKEN", None)          # never hand the token to a child
        proc = await asyncio.create_subprocess_exec(
            *cmd, cwd=str(workdir), env=env,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            limit=1 << 20)
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout + 30)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return JobResult(False, "the engine ran out of time", None, "", [],
                             time.monotonic() - started)
        status = redact(_status_line(out.decode("utf-8", "replace")))
        if not status:
            # stderr belongs in the log, never in a Discord embed
            LOG.log(logging.WARNING if proc.returncode else logging.DEBUG,
                    "engine stderr: %s", _redact_for_log(err.decode("utf-8", "replace")))
        if not output_path.is_file():
            return JobResult(False, status or "the engine stopped before writing a result",
                             None, "", [], time.monotonic() - started)
        data = output_path.read_bytes()
        if len(data) > max_output:
            return JobResult(False,
                             f"output is larger than the {max_output // (1024 * 1024)} MB limit",
                             None, "", [], time.monotonic() - started)
        payload = data                        # in memory from here on
        recovered = _read_recovered(workdir)  # also in memory
        if not payload.strip():
            # A validly terminated analysis with no observed script statements
            # is not a successful dump. Keep any recovered payload metadata, but
            # never upload an empty file or a CatLog-only comment banner.
            return JobResult(False,
                             "no executable script code was observed; no dump produced",
                             None, "", recovered, time.monotonic() - started)
        return JobResult(True, status or "finished", payload, "catlog_result.lua",
                         recovered, time.monotonic() - started)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


async def run_luraph_job(source: bytes, *, plugin: str, timeout: int = 180,
                         max_output: int = 8 * 1024 * 1024,
                         name: str = "input.lua") -> JobResult:
    """Run the bundled Luraph v14/v15 source lifter, without trace fallback.

    `plugin` is selected from the validated version banner by the caller and is
    restricted here too. If the upstream pipeline falls back to a behavior
    trace, that trace is deliberately not returned as a successful deobfuscation.
    """
    import time

    if plugin not in {"luraph_v14", "luraph_v15"}:
        raise ValueError("unsupported Luraph plugin")
    started = time.monotonic()
    workdir = Path(tempfile.mkdtemp(prefix="catlog_luraph_"))
    try:
        input_path = workdir / "input.lua"
        output_path = workdir / "result.lua"
        input_path.write_bytes(source)
        node = os.environ.get("NODE_BIN") or shutil.which("node")
        if not node or not LURAPH_DRIVER.is_file():
            return JobResult(False, "the Luraph lifter is not installed on this host",
                             None, "", [], time.monotonic() - started)

        env = dict(os.environ)
        env.pop("DISCORD_TOKEN", None)
        env.setdefault("LUAU_BIN", str(HERE.parent / ".luau-local"))
        cmd = [node, str(LURAPH_DRIVER), str(input_path), "--plugin", plugin,
               "-o", str(output_path), "--timeout", str(timeout),
               "--budget", str(timeout)]
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd, cwd=str(LURAPH_PLUGIN), env=env,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                limit=1 << 20)
            out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout + 30)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return JobResult(False, "the Luraph lifter ran out of time", None, "", [],
                             time.monotonic() - started)
        except OSError as exc:
            LOG.warning("Luraph lifter could not start: %s", type(exc).__name__)
            return JobResult(False, "the Luraph lifter could not start on this host",
                             None, "", [], time.monotonic() - started)

        log = (out + b"\n" + err).decode("utf-8", "replace")
        if proc.returncode != 0 or not output_path.is_file():
            LOG.warning("Luraph lifter failed: %s", _redact_for_log(log))
            return JobResult(False, "the Luraph lifter could not recover this sample",
                             None, "", [], time.monotonic() - started)
        if re.search(r"writing (?:the )?behavio[u]?r trace|devirtualization produced no output",
                     log, re.IGNORECASE):
            return JobResult(False, "no source lift was produced; behavior traces are not substituted",
                             None, "", [], time.monotonic() - started)
        data = output_path.read_bytes()
        if not data.strip():
            return JobResult(False, "the Luraph lifter produced an empty result",
                             None, "", [], time.monotonic() - started)
        if len(data) > max_output:
            return JobResult(False,
                             f"output is larger than the {max_output // (1024 * 1024)} MB limit",
                             None, "", [], time.monotonic() - started)
        label = "v14 experimental" if plugin == "luraph_v14" else "v15"
        return JobResult(True, f"Luraph {label} source lift finished", data,
                         "luraph_deobfuscated.lua", [], time.monotonic() - started)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def luraph_problem() -> str | None:
    """Check only the local prerequisites used by the dedicated Luraph lifter."""
    if not LURAPH_DRIVER.is_file():
        return "the Luraph lifter is not installed on this host"
    if not (os.environ.get("NODE_BIN") or shutil.which("node")):
        return "Node.js is not installed on this host"
    sys.path.insert(0, str(HERE.parent / "catlog"))
    import binpath
    for name in ("luau", "luau-ast"):
        path = binpath.tool(name)
        if not os.path.isfile(path):
            return f"{name} is not installed on this host"
        if not os.access(path, os.X_OK):
            try:
                os.chmod(path, 0o755)
            except OSError:
                return f"{name} is not executable on this host"
        if not os.access(path, os.X_OK):
            return f"{name} is not executable on this host"
        problem = binpath.arch_problem(path)
        if problem:
            return f"{name} is {problem}"
    return None


def _safe_name(name: str) -> str:
    """A fixed, harmless filename for the input.

    The attachment name is never used as a path: only its extension survives,
    and only if the extension is one we already allow. ``"; rm -rf ~"`` becomes
    ``input.lua``, so the worst a hostile name can do is nothing.
    """
    suffix = Path(name).suffix.lower() if name else ""
    return "input" + (suffix if suffix in {".lua", ".luau", ".txt", ".zip"} else ".lua")


def _redact_for_log(text: str) -> str:
    """Keep the shape of an error for debugging, drop every absolute path."""
    text = re.sub(r"(/[\w.\-]+){2,}", "<path>", text or "")
    return text.strip()[-400:]


def _status_line(text: str) -> str:
    """The engine prints `[*] <status>` on stderr: take the status, not the marker."""
    for line in text.splitlines():
        if line.startswith("[*] "):
            return line[4:].strip()
    return ""


def engine_problem() -> str | None:
    """Why `.l` would fail right now, in words a user can act on — or None.

    The architecture is part of the check: an x86-64 binary committed by mistake
    on an aarch64 host looks present, is executable, and dies with
    "Exec format error" the moment it runs.
    """
    if not ENGINE.is_file():
        return "the engine is not installed on this host"
    sys.path.insert(0, str(HERE.parent / "catlog"))
    try:
        import binpath                                # noqa: PLC0415
    except Exception:                                # noqa: BLE001
        return None                                  # let the engine report the real error
    for name in ("luau", "luau-compile"):
        path = binpath.tool(name)
        if not os.path.isfile(path):
            return f"{name} is not installed on this host"
        if not os.access(path, os.X_OK):
            return f"{name} is not executable on this host"
        problem = binpath.arch_problem(path)
        if problem:
            return f"{name} is {problem}"
    return None


def engine_available() -> bool:
    """Engine present **and** runnable: the Luau binaries are part of the engine."""
    return engine_problem() is None
