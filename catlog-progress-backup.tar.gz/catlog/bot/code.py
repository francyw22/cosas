"""Code pasted straight into a message: ```fenced``` blocks and `inline` code.

A prefix command arrives as one message, so the script has to be taken out of
the text without eating the command itself, the prose around it, or the
backticks that delimit it.

Order of preference when a message has both: fenced block, then inline code.
An unclosed fence (someone hit send too early, or Discord swallowed the closing
one) takes the rest of the message rather than nothing.

There is no size limit here beyond Discord's own: a message is at most 4000
characters, so a pasted script is small by construction. Anything bigger belongs
in an attachment, and that route is unchanged.
"""
from __future__ import annotations

import re

# ```lang\n ... ```  |  ```lang ... ```  |  ``` ... ```  (unclosed at the end)
FENCE = re.compile(r"```[ \t]*([A-Za-z0-9_+-]{0,20})[ \t]*\r?\n(.*?)(?:```|\Z)", re.S)
FENCE_NO_NEWLINE = re.compile(r"```[ \t]*([A-Za-z0-9_+-]{0,20})[ \t]+([^`]+?)(?:```|\Z)", re.S)
INLINE = re.compile(r"`([^`\n]+)`")

MIN_CODE = 3            # fewer characters than this is not a script


def _looks_like_lua(text: str) -> bool:
    return bool(re.search(r"\b(local|function|return|print|game|task|while|for|if)\b", text))


def extract_code(content: str, prefix: str = ".") -> str:
    """The script inside ``content``, or '' when there is none.

    The command word (``.l``) is always stripped first, so `.l ```lua print(1)``` `
    yields `print(1)` and never `.l print(1)`.
    """
    if not content:
        return ""
    text = content
    stripped = text.strip()
    if stripped.startswith(prefix):
        # drop only the command word: ".l", ".get", ".detect"
        parts = stripped.split(None, 1)
        text = parts[1] if len(parts) > 1 else ""
    if not text.strip():
        return ""

    blocks = [body for _tag, body in FENCE.findall(text)]
    blocks += [body for _tag, body in FENCE_NO_NEWLINE.findall(text)]
    blocks = [b.strip("\n") for b in blocks if b and b.strip()]

    # a fenced block that was opened but never closed is caught by FENCE's \Z
    if blocks:
        # the biggest block is the script; a tiny one is usually an example in prose
        blocks.sort(key=len, reverse=True)
        return blocks[0] if len(blocks[0]) >= MIN_CODE else ""

    inline = [m.strip() for m in INLINE.findall(text) if m.strip()]
    if inline:
        inline.sort(key=len, reverse=True)
        best = inline[0]
        if len(best) >= MIN_CODE and _looks_like_lua(best):
            return best
        return ""
    return ""


def has_code(content: str, prefix: str = ".") -> bool:
    return bool(extract_code(content, prefix))


def name_for(code: str) -> str:
    """A harmless filename for a pasted script."""
    return "pasted.lua" if code else ""
