"""CatLog Discord bot (prefix commands only)."""
