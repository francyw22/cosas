"""A zip attachment, read **inside the host** so the engine only ever sees files.

CatLog cannot hand every `.zip` to the engine: a Roblox zip is usually a folder
of scripts plus `require`d modules, and the engine runs one script. So the
archive is expanded here, in memory, with no temporary files and no shell, and
each entry is returned as plain text. There is deliberately no extraction to
disk: nothing can be written outside a filename we choose, because no filename
we did not choose is ever used.

The rules are the ones a careful person would write:

* a member whose path escapes the archive (``../../etc/passwd``, ``/etc/passwd``,
  ``C:\\``, a drive letter, a backslash trick) is **refused and reported**, never
  used as a path;
* a member larger than ``PER_FILE`` or an archive larger than ``TOTAL`` is
  refused by looking at the header, so a zip bomb is never decompressed;
* symlinks, encrypted members and directories are skipped;
* the order is stable: entry point first, then the rest by name.
"""
from __future__ import annotations

import io
import zipfile
from dataclasses import dataclass, field
from pathlib import PurePosixPath

PER_FILE = 2 * 1024 * 1024          # 2 MB of text is already a huge script
TOTAL = 6 * 1024 * 1024
MAX_FILES = 40
SCRIPT_SUFFIXES = (".lua", ".luau", ".txt")


@dataclass
class Entry:
    name: str                       # safe, normalised, no directories outside
    text: str
    size: int


@dataclass
class Archive:
    entries: list[Entry] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return bool(self.entries)

    def pick_main(self) -> Entry | None:
        """The file to hand to the engine: ``init.lua``, else the biggest script."""
        for name in ("init.lua", "main.lua", "index.lua", "init.luau", "main.luau"):
            for e in self.entries:
                if PurePosixPath(e.name).name.lower() == name:
                    return e
        scripts = [e for e in self.entries if e.name.lower().endswith(SCRIPT_SUFFIXES)]
        return max(scripts, key=lambda e: e.size) if scripts else (self.entries[0] if self.entries else None)

    def extras(self, main: Entry | None) -> list[tuple[str, bytes]]:
        """Every other file, as ``(filename, bytes)`` for a Discord message."""
        out = []
        for e in self.entries:
            if main is not None and e.name == main.name:
                continue
            out.append((PurePosixPath(e.name).name, e.text.encode("utf-8")))
        return out


def is_zip(data: bytes) -> bool:
    return data[:2] == b"PK" or data[:4] in (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")


def _safe_member(name: str) -> str | None:
    """Normalise a member name, or None if it tries to leave the archive."""
    if not name or "\x00" in name:
        return None
    cleaned = name.replace("\\", "/")          # backslash is a separator on Windows
    if cleaned.startswith("/") or cleaned.startswith("~"):
        return None
    parts = []
    for part in cleaned.split("/"):
        if part in ("", "."):
            continue
        if part == ".." or part.endswith(":"):  # traversal or drive letter
            return None
        parts.append(part)
    if not parts:
        return None
    return "/".join(parts)


def read_zip(data: bytes) -> Archive:
    """Expand ``data`` in memory. Never raises for a malformed archive."""
    archive = Archive()
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError) as exc:
        archive.skipped.append(f"not a readable zip ({type(exc).__name__})")
        return archive

    total = 0
    with zf:
        for info in zf.infolist()[:MAX_FILES * 4]:
            if info.is_dir():
                continue
            if len(archive.entries) >= MAX_FILES:
                archive.skipped.append(f"more than {MAX_FILES} files; the rest were skipped")
                break
            safe = _safe_member(info.filename)
            if safe is None:
                archive.skipped.append(f"unsafe path refused: {info.filename!r}")
                continue
            if not safe.lower().endswith(SCRIPT_SUFFIXES):
                archive.skipped.append(f"not a text script, skipped: {info.filename!r}")
                continue
            if info.flag_bits & 0x1:
                archive.skipped.append(f"encrypted, cannot read: {info.filename!r}")
                continue
            if info.file_size > PER_FILE:
                archive.skipped.append(
                    f"larger than {PER_FILE // (1024 * 1024)} MB, refused: {info.filename!r}")
                continue
            if total + info.file_size > TOTAL:
                archive.skipped.append(f"archive is bigger than {TOTAL // (1024 * 1024)} MB; stopped")
                break
            try:
                raw = zf.read(info)
            except (zipfile.BadZipFile, RuntimeError, OSError) as exc:
                archive.skipped.append(f"could not read {info.filename!r} ({type(exc).__name__})")
                continue
            total += len(raw)
            archive.entries.append(Entry(safe, raw.decode("utf-8", "replace"), len(raw)))

    main = archive.pick_main()
    if main is not None:                       # entry point first, deterministic order
        archive.entries.sort(key=lambda e: (e.name != main.name, e.name))
    else:
        archive.entries.sort(key=lambda e: e.name)
    return archive
