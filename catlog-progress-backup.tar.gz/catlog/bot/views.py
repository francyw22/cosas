"""Interactive views: the result panel, the help menu and the support ticket.

Every view is explicit about ``timeout``: a view that outlives its message is a
view whose buttons lie. Buttons that a user may not press answer with a short
private message instead of failing silently or acting on someone else's job.
"""
from __future__ import annotations

import discord

from . import ui

# ---------------------------------------------------------------------------
# Result panel
# ---------------------------------------------------------------------------


class ResultView(discord.ui.View):
    """Buttons under a finished job: download again, show details, ask for help."""

    def __init__(self, *, owner_id: int, result_bytes: bytes, output_name: str,
                 status: str, seconds: float, links: dict[str, str]) -> None:
        super().__init__(timeout=900)
        self.owner_id = owner_id
        self.result_bytes = result_bytes
        self.output_name = output_name
        self.status = status
        self.seconds = seconds
        self.links = links

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "That panel belongs to another job. Run `.l` or `.luraph` yourself to get your own.",
                ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Download again", style=discord.ButtonStyle.primary, emoji="📄")
    async def download(self, interaction: discord.Interaction, _: discord.ui.Button) -> None:
        await interaction.response.send_message(
            file=discord.File(fp=_bytes_io(self.result_bytes), filename=self.output_name),
            ephemeral=True)

    @discord.ui.button(label="Details", style=discord.ButtonStyle.secondary, emoji="🔎")
    async def details(self, interaction: discord.Interaction, _: discord.ui.Button) -> None:
        await interaction.response.send_message(
            embed=ui.embed(
                "Job details",
                "What CatLog did with your file.",
                fields=[
                    ("Run status", self.status or "unknown", False),
                    ("Time", ui.human_seconds(self.seconds), True),
                    ("Output size", ui.human_bytes(len(self.result_bytes)), True),
                    ("Links", ui.link_lines(self.links) or "—", False),
                ]),
            ephemeral=True)

    @discord.ui.button(label="Get support", style=discord.ButtonStyle.success, emoji="🛟")
    async def support(self, interaction: discord.Interaction, _: discord.ui.Button) -> None:
        await interaction.response.send_message(
            embed=support_embed(self.links, status=self.status), ephemeral=True)


# ---------------------------------------------------------------------------
# Help
# ---------------------------------------------------------------------------


class HelpView(discord.ui.View):
    """Two pages: what the bot does, and how to get help."""

    def __init__(self, *, prefix_hint: str, links: dict[str, str]) -> None:
        super().__init__(timeout=300)
        self.prefix_hint = prefix_hint
        self.links = links
        self.page = 0

    def page_embed(self) -> discord.Embed:
        if self.page == 0:
            return ui.embed(
                "CatLog — what this bot does",
                "CatLog dumps an obfuscated script in a fake environment built to be as "
                "close to Roblox as possible, then writes back everything the script "
                "actually did.",
                fields=[
                    (".l", "Dump a script. Attach it, paste it in a code block, "
                           "reply `.l` to a message that has one, or paste a link — a whole "
                           "`loadstring(game:HttpGet(\"https://…\"))()` line works too.", False),
                    (".luraph", "Run the dedicated Luraph source lifter for v14.7–v14.9 "
                                "(experimental) and v15.0–v15.1. It refuses to pass off a "
                                "behavior trace as recovered source.", False),
                    (".get", "Fetch the script behind a link and send it back exactly as it "
                             "was served, without running anything.", False),
                    (".detect", "Name the obfuscator used — nothing is executed.", False),
                    (".support", "Open a private ticket with a link you can share.", False),
                    (".links", "Every official link for this bot.", False),
                ],
                footer="Page 1/2 · use the buttons to switch")
        return ui.embed(
            "Getting help",
            "Something went wrong, or a script came out wrong?",
            fields=[
                ("Support", ui.link_lines({"Support server": self.links["Support server"]})
                 if "Support server" in self.links else "No support server configured.", False),
                ("Links", ui.link_lines({k: v for k, v in self.links.items()
                                         if k != "Support server"}) or "—", False),
                ("What to include", "The script you uploaded and a short description of "
                                    "what you expected to see.", False),
            ],
            footer="Page 2/2 · use the buttons to switch")

    @discord.ui.button(label="What it does", style=discord.ButtonStyle.primary)
    async def first(self, interaction: discord.Interaction, _: discord.ui.Button) -> None:
        self.page = 0
        await interaction.response.edit_message(embed=self.page_embed(), view=self)

    @discord.ui.button(label="Get help", style=discord.ButtonStyle.secondary)
    async def second(self, interaction: discord.Interaction, _: discord.ui.Button) -> None:
        self.page = 1
        await interaction.response.edit_message(embed=self.page_embed(), view=self)


# ---------------------------------------------------------------------------
# Support
# ---------------------------------------------------------------------------


def support_embed(links: dict[str, str], *, status: str = "") -> discord.Embed:
    fields = []
    if status:
        fields.append(("Your last run", status, False))
    fields.append(("Support server", links.get("Support server", "not configured"), False))
    rest = {k: v for k, v in links.items() if k != "Support server"}
    if rest:
        fields.append(("Other links", ui.link_lines(rest), False))
    fields.append(("When you ask for help, include",
                   "the script you uploaded and a short description of what you expected.",
                   False))
    return ui.embed("CatLog support", "Here is how to reach a human.", fields=fields)


class SupportModal(discord.ui.Modal, title="CatLog support request"):
    summary = discord.ui.TextInput(
        label="What happened?",
        style=discord.TextStyle.paragraph,
        max_length=900,
        placeholder="what went wrong, in your own words")
    details = discord.ui.TextInput(
        label="Anything else? (optional)",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=900,
        placeholder="what you expected to see")

    def __init__(self, links: dict[str, str], status: str) -> None:
        super().__init__()
        self.links = links
        self.status = status

    async def on_submit(self, interaction: discord.Interaction) -> None:
        ticket = (
            f"**Support request from {interaction.user}** (`{interaction.user.id}`)\n"
            f"**Last run status:** {self.status or 'no run in this session'}\n\n"
            f"**What happened**\n{self.summary.value}\n\n"
            f"**Extra**\n{self.details.value or '—'}\n"
        )
        await interaction.response.send_message(
            embed=ui.embed(
                "Ticket ready",
                "Your report is formatted below. Copy it into the support server — this keeps "
                "your file private instead of posting it in a public channel.",
                fields=[("Your ticket", ui.clip(ticket, 1000), False),
                        ("Support server", self.links.get("Support server", "not configured"), False)],
                colour=ui.OK),
            ephemeral=True)


def _bytes_io(data: bytes):
    import io
    return io.BytesIO(data)
