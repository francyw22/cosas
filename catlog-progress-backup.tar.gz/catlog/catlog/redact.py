"""Strip every comment from CatLog's output, keep one banner.

The rule for this project: a delivered file contains code and **exactly one**
comment line:

    -- Logged with Catmio | https://discord.gg/2aDSEyhcq

Stripping comments from Lua is a lexing problem, not a regex problem: `--` can
appear inside a string (`"https://x--y"`), and a quoted string can contain
`--[[`. So this walks the source with a real (small) lexer that understands:

    "..."  '...'  [[...]]  [==[...]==]   -- line comment   --[[ block comment ]]

The line count is preserved (multi-line comments become the same number of
newlines) so line numbers in error messages still match the trace. If a Luau
compiler is available, the stripped result is compiled to prove nothing broke.
"""
from __future__ import annotations

import os
import subprocess
import tempfile

BANNER = "-- Logged with Catmio | https://discord.gg/2aDSEyhcq"

_QUOTE = {'"', "'"}


def _long_bracket_open(src: str, i: int) -> tuple[int, int] | None:
    """``[[`` / ``[==[`` at ``i`` -> (level, index just past the opening)."""
    if i >= len(src) or src[i] != "[":
        return None
    j = i + 1
    level = 0
    while j < len(src) and src[j] == "=":
        level += 1
        j += 1
    if j < len(src) and src[j] == "[":
        return level, j + 1
    return None


def strip_comments(src: str) -> str:
    """Return ``src`` without any comment, line numbers preserved."""
    out: list[str] = []
    i = 0
    n = len(src)
    while i < n:
        ch = src[i]
        # quoted string: copy untouched
        if ch in _QUOTE:
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == ch:
                    j += 1
                    break
                j += 1
            out.append(src[i:j])
            i = j
            continue
        # long string: copy untouched
        if ch == "[":
            opened = _long_bracket_open(src, i)
            if opened:
                level, after = opened
                close = "]" + "=" * level + "]"
                end = src.find(close, after)
                end = n if end < 0 else end + len(close)
                out.append(src[i:end])
                i = end
                continue
        # comment
        if ch == "-" and i + 1 < n and src[i + 1] == "-":
            opened = _long_bracket_open(src, i + 2)
            if opened:
                level, after = opened
                close = "]" + "=" * level + "]"
                end = src.find(close, after)
                end = n if end < 0 else end + len(close)
                body = src[i:end]
                out.append("\n" * body.count("\n"))
                i = end
                continue
            end = src.find("\n", i)
            end = n if end < 0 else end
            out.append("")                    # drop the comment, keep the newline below
            i = end
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _compiles(code: str) -> bool | None:
    """True/False, or None when there is no compiler to ask."""
    exe = os.path.join(os.environ.get("LUAU_BIN", ""), "luau-compile")
    if not os.path.isfile(exe):
        return None
    fd, path = tempfile.mkstemp(suffix=".luau")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(code)
        r = subprocess.run([exe, path], capture_output=True, timeout=120)
        return b"SyntaxError" not in (r.stdout + r.stderr)
    except (OSError, subprocess.SubprocessError):
        return None
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def clean_output(code: str, *, verify: bool = True) -> str:
    """Banner + comment-free code. Raises if the result no longer compiles."""
    body = strip_comments(code)
    # no more than one blank line in a row, and no trailing space
    lines = [line.rstrip() for line in body.splitlines()]
    squeezed: list[str] = []
    blanks = 0
    for line in lines:
        if line:
            blanks = 0
            squeezed.append(line)
        else:
            blanks += 1
            if blanks <= 1:
                squeezed.append("")
    text = BANNER + "\n" + "\n".join(squeezed).strip("\n") + "\n"
    if verify:
        ok = _compiles(text)
        if ok is False:
            raise ValueError("stripping comments broke the output; refusing to deliver it")
    return text
