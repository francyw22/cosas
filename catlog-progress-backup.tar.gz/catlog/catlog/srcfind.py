#!/usr/bin/env python3
"""srcfind: saca el codigo fuente que venga DENTRO de un payload recuperado.

Los obfuscadores no entregan el codigo de una forma unica. En este corpus, lo
recuperado es, segun la familia:

  - un blob cifrado (nada que sacar),
  - bytecode (nada que sacar sin decompilador),
  - la tabla de constantes del VM (cadenas sueltas, no codigo),
  - **la fuente en claro**, a veces en UTF-16, a veces sin saltos de linea entre
    sentencias (`elseif x then ... for i,v in pairs(...) do`), a veces mezclada
    con un blob binario delante.

Este modulo ataca el ultimo caso con criterio medible: parte de las lineas que
YA son Lua valido, las valida una a una con `luau-compile`, y solo despues
reconstruye las lineas partidas probando puntos de corte. Nada se da por bueno
sin que el compilador lo acepte.
"""
import os
import re
import subprocess
import tempfile

LUAU = os.path.join(os.environ.get("LUAU_BIN", "/home/user/.luau-bin"), "luau-compile")

# lineas que son Lua valido por si solas (una sentencia completa)
STMT = re.compile(
    r"^\s*(?:local\s+[\w, _]+\s*=|if\s|elseif\s|else\b|end\b|for\s|while\s|repeat\b|until\s|"
    r"return\b|break\b|do\b|function\s|[\w.:\[\]\"' ]+\s*=[^=]|[\w.:\[\]\"']+\s*\(|--)")


def _printable_ratio(text):
    if not text:
        return 0.0
    good = sum(1 for c in text if c >= " " or c in "\n\r\t")
    return good / len(text)


def decode_text_forms(blob):
    """El payload tal cual y, si procede, decodificado de UTF-16."""
    out = [("latin-1", blob.decode("latin-1"))]
    if len(blob) >= 8 and _printable_ratio(blob.decode("latin-1")) < 0.85:
        for enc, name in (("utf-16-le", "utf-16le"), ("utf-16-be", "utf-16be")):
            try:
                text = blob.decode(enc)
            except UnicodeDecodeError:
                continue
            if _printable_ratio(text) > 0.95 and text.count("\n") >= 3:
                out.append((name, text))
    return out


def text_region(text):
    """Recorta al tramo de texto: descarta el blob binario que pueda ir delante."""
    if _printable_ratio(text) > 0.9:
        return text, 0
    # el codigo suele ir al final: buscar el ultimo tramo largo imprimible
    best = (0, 0)
    start = None
    for i, c in enumerate(text):
        ok = c >= " " or c in "\n\r\t"
        if ok and start is None:
            start = i
        elif not ok and start is not None:
            if i - start > best[1] - best[0]:
                best = (start, i)
            start = None
    if start is not None and len(text) - start > best[1] - best[0]:
        best = (start, len(text))
    return text[best[0]:best[1]], best[0]


def compiles(code):
    if not code.strip():
        return False
    if b"\x00" in code.encode("latin-1", "replace"):
        return False
    with tempfile.NamedTemporaryFile("wb", suffix=".luau", delete=False) as f:
        f.write(code.encode("latin-1", "replace"))
        path = f.name
    try:
        r = subprocess.run([LUAU, path], capture_output=True)
        return b"SyntaxError" not in (r.stdout + r.stderr)
    finally:
        os.unlink(path)


def split_flat(line, max_parts=4000):
    """Parte una linea sin saltos (`a=1 b=2 for i,v in ... do`) en sentencias.

    Estrategia: cortes candidatos en los sitios donde Lua empieza sentencia y
    aceptar un corte solo si la parte izquierda ya compila sola. Se prueban de
    mayor a menor para quedarse con el trozo mas grande valido.
    """
    bounds = [m.start() for m in re.finditer(
        r"(?=\b(?:local\s|if\s|for\s|while\s|repeat\b|until\s|return\b|elseif\s|else\b|end\b|do\b|function\s))",
        line)]
    bounds = [0] + [b for b in bounds if b > 0] + [len(line)]
    parts = []
    start = 0
    while start < len(line) and len(parts) < max_parts:
        cut = None
        for b in reversed(bounds):
            if b <= start:
                continue
            piece = line[start:b]
            if not piece.strip():
                continue
            if compiles(piece):
                cut = b
                break
        if cut is None:
            break
        parts.append(line[start:cut])
        start = cut
    if start < len(line):
        parts.append(line[start:])
    return parts


def find_code_start(text, min_run=25):
    """Indice donde empieza el codigo: la primera tirada de lineas 'de codigo'."""
    lines = text.split("\n")
    pos = 0
    run = 0
    start = None
    for l in lines:
        looks = bool(STMT.match(l)) and len(l.strip()) > 2
        if looks:
            if run == 0:
                start = pos
            run += 1
            if run >= min_run:
                return start
        elif l.strip():
            run = 0
            start = None
        pos += len(l) + 1
    return None


def _repair(code):
    """Cierra bloques abiertos al final del texto."""
    opens = len(re.findall(r"\b(?:function|if|for|while|repeat)\b", code))
    closes = len(re.findall(r"\bend\b", code)) + len(re.findall(r"\buntil\b", code))
    if closes < opens:
        code += "\n" + "end\n" * (opens - closes)
    return code


def _depth(code):
    d = 0
    for w in re.findall(r"\b(function|if|for|while|repeat|do|then|else|elseif|end|until)\b", code):
        if w in ("function", "if", "for", "while", "repeat"):
            d += 1
        elif w in ("end", "until"):
            d -= 1
    return max(0, d)


def biggest_prefix(lines, start=0):
    """(n_lineas, texto) del mayor prefijo que compila, buscando desde el final."""
    lo, hi = 1, len(lines)
    best = (0, "")
    while lo <= hi:
        mid = (lo + hi) // 2
        cand = _repair("\n".join(lines[:mid]))
        if compiles(cand):
            best = (mid, cand)
            lo = mid + 1
        else:
            hi = mid - 1
    return best


def assemble(lines, min_chunk=3):
    """Reconstruye el fuente saltando los tramos que no son codigo.

    El payload trae la fuente partida por basura al final de cada bloque (la
    tabla de constantes del VM pegada al `end`). Se toma el mayor prefijo que
    compila, se deja abierto con `end`, y se sigue buscando el siguiente bloque
    compilable; si el trozo aporta lineas nuevas, se anade. Todo el resultado se
    valida otra vez con luau-compile.
    """
    out = []
    i = 0
    n = len(lines)
    chunks = 0
    while i < n:
        rest = lines[i:]
        # saltar lineas que no parecen codigo
        first = None
        for k, l in enumerate(rest[:40]):
            if STMT.match(l) and len(l.strip()) > 2:
                first = k
                break
        if first is None:
            break
        i += first
        rest = lines[i:]
        used, text = biggest_prefix(rest)
        if used < min_chunk:
            i += 1
            continue
        out.append(text)
        chunks += 1
        i += used + 1          # +1: la linea del corte lleva basura pegada
    if not out:
        return ""
    code = _repair("\n".join(out))
    return code if compiles(code) else ""


def extract(blob, min_lines=3):
    """Devuelve (codigo, informe). `codigo` es "" si no hay fuente que sacar.

    Se valida el TEXTO COMPLETO con luau-compile (no linea a linea: un bloque
    `for ... end` es codigo perfectamente valido pero no compila suelto). Si el
    archivo no compila, se intenta recortando por el final, que es donde suele
    quedar el resto de la tabla de constantes del VM.
    """
    report = {"forms": [], "compiles": False, "chars": 0}
    best = ""
    for name, text in decode_text_forms(blob):
        report["forms"].append({"encoding": name, "chars": len(text)})
        start = find_code_start(text)
        if start is None:
            continue
        region = text[start:]
        # quitar el relleno de separadores del principio
        region = re.sub(r"^(?:[-=*#]{4,}[ \t]*\r?\n)+", "", region)
        if len(region) < 200:
            continue
        body = _repair(region)
        if compiles(body):
            report["compiles"] = True
            if len(body) > len(best):
                best = body
                report["encoding"] = name
                report["chars"] = len(body)
            continue
        cand = assemble(region.split("\n"))
        if cand:
            report["compiles"] = True
            report["lines"] = cand.count("\n") + 1
            if len(cand) > len(best):
                best = cand
                report["encoding"] = name
                report["chars"] = len(cand)
    return best, report
