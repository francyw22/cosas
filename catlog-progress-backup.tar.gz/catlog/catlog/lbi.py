#!/usr/bin/env python3
"""lbi: saca el bytecode Lua 5.1 que va dentro de un payload de IronBrew/LuaObfuscator.

Los payloads de las familias LBI (Ironbrew1, IronBrew2, LuaObfuscator) llegan
como un *contenedor*: cabecera propia del obfuscador + bytecode byte a byte
encriptado (el "envelope" clasico de IronBrew: XOR que avanza una constante,
a veces sobre los ultimos N bytes). No hay decompilador de contenedores: lo que
se hace aqui es

  1. probar los esquemas de desencriptado conocidos (XOR con paso, con offset),
  2. mirar si el resultado empieza por la cabecera de Lua 5.1
     (\\x1bLua\\x51\\x00\\x01\\x04\\x08\\x04\\x08\\x00) o si el contenedor la lleva
     dentro con sus bytes ya en claro,
  3. y si aparece un chunk, decompilarlo con unluac (Java).

Todo lo que devuelve esta comprobado: o el chunk carga en un Lua 5.1 real, o no
se devuelve nada.
"""
import os
import subprocess
import tempfile

HDR = bytes([0x1B, 0x4C, 0x75, 0x61, 0x51, 0x00, 0x01, 0x04, 0x08, 0x04, 0x08, 0x00])
JAR = os.environ.get("UNLUAC_JAR", "/tmp/unluac.jar")


def _valid_chunk(blob):
    """¿carga este blob como chunk Lua 5.1? (lo comprueba un Lua 5.1 de verdad)"""
    try:
        import lupa.lua51 as l51
    except ImportError:
        return False
    rt = l51.LuaRuntime(unpack_returned_tuples=True, encoding=None)
    loader = rt.eval("function(s) local f, e = loadstring(s) return f, e end")
    try:
        fn, err = loader(blob)
    except Exception:                     # noqa: BLE001
        return False
    return fn is not None


def xor_variants(data, max_key=64):
    """Esquemas clasicos: XOR de un byte avanzando en el cuerpo del chunk."""
    start = data.find(HDR)
    base = data[start:] if start >= 0 else data
    out = []
    if start >= 0:
        out.append(base)                      # ya viene en claro
    for k in range(1, 256):
        for offset in (0,):
            body = bytes(b ^ ((k + i) & 0xFF) for i, b in enumerate(base[offset:]))
            out.append(HDR + body if not body.startswith(HDR) else body)
        if len(out) > max_key * 4:
            break
    return out


def try_container(blob):
    """Busca un chunk Lua 5.1 valido dentro de un contenedor LBI."""
    # 1. cabecera literal dentro del blob (chunk en claro o con huecos)
    if HDR in blob:
        i = blob.find(HDR)
        cand = blob[i:]
        if _valid_chunk(cand):
            return cand, "chunk en claro dentro del contenedor"
    # 2. desencriptado por XOR creciente sobre el cuerpo
    for k in range(0, 256):
        body = bytes((b ^ ((k + i) & 0xFF)) for i, b in enumerate(blob))
        cand = HDR + body
        if _valid_chunk(cand):
            return cand, "XOR creciente k=%d" % k
    # 3. XOR por bloques de 4/8 con la misma clave
    for size in (4, 8):
        for k in range(1, 256):
            body = bytes((b ^ k) for b in blob)
            cand = HDR + body
            if _valid_chunk(cand):
                return cand, "XOR fijo k=%d" % k
    return None, ""


def decompile(chunk):
    """unluac sobre un chunk ya validado. Devuelve (codigo, error)."""
    if not chunk:
        return "", "sin chunk"
    if not os.path.exists(JAR):
        return "", "unluac no disponible (%s)" % JAR
    with tempfile.NamedTemporaryFile("wb", suffix=".luac", delete=False) as f:
        f.write(chunk)
        path = f.name
    try:
        r = subprocess.run(["java", "-cp", JAR, "unluac.Main", path],
                           capture_output=True, timeout=120)
        out = r.stdout.decode("latin-1", "replace")
        err = r.stderr.decode("latin-1", "replace")
        if out.strip() and "error" not in err.lower()[:80]:
            return out, ""
        return "", (err or out).strip()[:300]
    finally:
        os.unlink(path)


def main():
    import sys
    if len(sys.argv) < 2:
        sys.exit("uso: lbi.py <payload.bin>")
    blob = open(sys.argv[1], "rb").read()
    chunk, how = try_container(blob)
    print("chunk:", len(chunk) if chunk else 0, "bytes |", how or "no encontrado")
    if chunk:
        code, err = decompile(chunk)
        print("decompilado:", len(code), "bytes", ("| " + err) if err else "")
        print(code[:800])


if __name__ == "__main__":
    main()
