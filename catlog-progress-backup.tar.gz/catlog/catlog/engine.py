"""
CatLog's dynamic engine runs scripts in its fake Roblox/executor environment
(catlog.luau + harness.py) and emits the observed behavior trace. A vendored,
MIT-licensed Luraph VM lifter adds static lifting for supported v14/v15 builds;
other inputs continue through CatLog's normal trace pipeline.
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

import harness
import traceout as trace

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
try:
    from bot.detector import best as _best_fingerprint
except ImportError:                              # standalone engine checkout
    _best_fingerprint = None


def _family_of(path):
    """Nombre de familia = carpeta de la muestra (samples/terrorlua/<familia>/x.lua)."""
    parts = os.path.normpath(os.path.abspath(path)).split(os.sep)
    return parts[-2] if len(parts) >= 2 else ""


class Job:
    """Lo minimo que harness.Runner necesita de un trabajo."""

    def __init__(self, input_path, trace_path, args):
        self.input = input_path
        self.trace_path = trace_path
        self.args = args


def static_source(name, source, allow_external=False):
    """Fuente real de familias con backend estatico probado (ver deobf/backends).

    Solo se devuelve si compila como Luau: un decompilador que escupe basura no
    cuenta como "he sacado la fuente". Devuelve (codigo, motivo_si_no).
    """
    # CatLog es el motor. Las herramientas de terceros NO son fallback: solo
    # corren si se piden explicitamente con --allow-external.
    if not allow_external:
        return None, "herramientas externas desactivadas (usa --allow-external)"
    low = name.lower()
    if low == "luaobfuscator":
        try:
            import luaobf
        except ImportError as e:                       # noqa: BLE001
            return None, "luaobf.py no importable: %s" % e
        return luaobf.static_source(source)
    if low in ("ironbrew2", "aztupbrew"):
        code, why = ib2_deobf(source)
        if code:
            return ("-- Devirtualizado con LuaAnalysis.Ironbrew2 (herramienta externa).\n"
                    "-- Es el programa del VM con los opcodes resueltos, NO fuente original.\n\n" + code), None
        return None, why
    return None, "sin backend estatico para " + name



def ib2_deobf(source):
    """Devirtualiza IronBrew2 con LuaAnalysis.Ironbrew2 (herramienta externa).

    Es un binario .NET en /home/user/tools/ib2deobf. Devuelve el programa del VM
    devirtualizado (legible, con el switch de opcodes resuelto), no fuente
    original: la estructura del interprete sigue ahi, sin los handlers.
    """
    root = os.environ.get("IB2_DIR", "/home/user/tools/ib2deobf")
    dotnet = os.environ.get("DOTNET_BIN", "/home/user/.dotnet/dotnet")
    dll = os.path.join(root, "LuaAnalysis.Ironbrew2.dll")
    if not (os.path.isfile(dll) and os.path.isfile(dotnet)):
        return None, "LuaAnalysis.Ironbrew2 o dotnet no disponibles"
    inp = tempfile.mktemp(suffix=".lua")
    out = os.path.join(root, "output.lua")
    with open(inp, "w", encoding="utf-8") as f:
        f.write(source)
    try:
        subprocess.run([dotnet, dll, inp], cwd=root, capture_output=True,
                       text=True, timeout=900)
    except subprocess.TimeoutExpired:
        return None, "el devirtualizador agoto el tiempo"
    finally:
        try:
            os.unlink(inp)
        except OSError:
            pass
    if not os.path.isfile(out):
        return None, "no escribio output.lua (probablemente no es IronBrew2)"
    code = open(out, encoding="utf-8", errors="replace").read()
    try:
        os.unlink(out)
    except OSError:
        pass
    if not code.strip() or not _parses_luau(code):
        return None, "la salida del devirtualizador no compila"
    return code, None


def _parses_luau(code):
    comp = os.path.join(os.environ.get("LUAU_BIN", os.path.join(PROJECT_ROOT, ".luau-local")), "luau-compile")
    if not os.path.isfile(comp):
        return True
    path = tempfile.mktemp(suffix=".luau")
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)
    try:
        r = subprocess.run([comp, path], capture_output=True, timeout=180)
        return b"SyntaxError" not in (r.stdout + r.stderr)
    finally:
        os.unlink(path)


def luraph_source(source, input_path, out_path, args):
    """Run the vendored Luraph v14/v15 devirtualizer when the input matches.

    The upstream lifter is MIT licensed; its own v14 and v15 engines select
    their version-specific passes. If its prerequisites or lift are unavailable,
    return None so CatLog can still produce its ordinary behavior trace.
    """
    header = re.search(r"This file (?:was )?(?:protected|generated) (?:using|with) Luraph Obfuscator v\d+", source[:1000], re.I)
    vm_shape = ("return setmetatable({" in source[:65536]
                and re.search(r"\[\s*\d+\]\s*=\s*(?:bit32|buffer|string|table|math)\.", source[:65536]))
    if not header and not vm_shape:
        return None, "not a Luraph VM"

    node = os.environ.get("NODE_BIN") or shutil.which("node")
    if not node:
        return None, "Node.js is required for Luraph source lifting"
    plugin = os.path.join(os.path.dirname(os.path.abspath(__file__)), "luraph")
    script = os.path.join(plugin, "deob.js")
    if not os.path.isfile(script):
        return None, "Luraph engine files are missing"

    timeout = min(900, max(30, int(getattr(args, "timeout", 60))))
    budget = max(10, int(getattr(args, "budget", None) or timeout))
    env = os.environ.copy()
    env.setdefault("LUAU_BIN", os.path.join(PROJECT_ROOT, ".luau-local"))
    try:
        with tempfile.TemporaryDirectory(prefix="catlog-luraph-") as work:
            inp = os.path.join(work, "input.lua")
            out = os.path.join(work, "output.lua")
            with open(inp, "w", encoding="latin-1", newline="") as f:
                f.write(source)
            cmd = [node, script, inp, "-o", out, "--timeout", str(timeout),
                   "--budget", str(budget), "--devirt-rounds", "200"]
            if getattr(args, "input_text", None) is not None:
                cmd.extend(("--input-text", args.input_text))
            if getattr(args, "executor", None):
                cmd.extend(("--executor", args.executor))
            try:
                proc = subprocess.run(cmd, cwd=plugin, env=env, capture_output=True,
                                      text=True, timeout=timeout + 30)
            except subprocess.TimeoutExpired:
                return None, "Luraph lift exceeded its host timeout"
            if proc.stderr:
                print(proc.stderr.rstrip(), file=sys.stderr)
            if proc.returncode != 0 or not os.path.isfile(out):
                detail = (proc.stderr or proc.stdout or "Luraph engine failed").strip()[-500:]
                return None, detail
            with open(out, encoding="utf-8", errors="replace") as f:
                code = f.read()
            if not code.strip() or not _parses_luau(code):
                return None, "Luraph engine produced empty or invalid Luau"
            with open(out_path, "w", encoding="utf-8", newline="\n") as f:
                f.write(code)
            print("[*] Luraph result: %d bytes (lift quality depends on VM version and sample)" % len(code.encode("utf-8")))
            return out_path, None
    except OSError as exc:
        return None, "Luraph engine could not start: " + type(exc).__name__


def _deobfuscate(input_path, source, out_path, args):
    """Ejecuta `source` en el mock y escribe la traza legible en `out_path`."""
    # Prometheus is still run by CatLog's instrumented Luau runtime. Its
    # content fingerprint only enables compatibility semantics for private
    # mixed-case VM globals; it never selects a source deobfuscator.
    detected_prometheus = False
    if _best_fingerprint:
        hit, _hits = _best_fingerprint(source)
        detected_prometheus = bool(hit and hit.obfuscator == "prometheus")
    name = getattr(args, "obfuscator", None) or \
        ("prometheus" if detected_prometheus else _family_of(input_path))
    prometheus_mode = detected_prometheus or name.lower() == "prometheus"
    if not prometheus_mode:
        luraph_result, luraph_error = luraph_source(source, input_path, out_path, args)
        if luraph_result:
            return luraph_result
        if luraph_error != "not a Luraph VM":
            print("[!] Luraph lift unavailable; continuing with CatLog behavior trace: " + luraph_error,
                  file=sys.stderr)
    code, why = (None, None) if prometheus_mode else \
        static_source(name, source, getattr(args, "allow_external", False))
    if code:
        with open(out_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(code)
        print("[*] fuente estatica (%s): %d bytes" % (name, len(code)))
        print("[+] result: " + out_path)
        return out_path
    if getattr(args, "allow_external", False) and name.lower() in ("luaobfuscator", "ironbrew2"):
        print("[!] herramienta externa no disponible:", why, file=sys.stderr)
    workdir = tempfile.mkdtemp(prefix="deobf_")
    trace_path = os.path.join(workdir, os.path.basename(input_path) + ".deobf.luau")
    cache_path = harness.load_p2d_cache(input_path, getattr(args, "studio", False))
    job = Job(input_path, trace_path, args)
    runner = harness.Runner(job)
    cfg = harness.user_cfg(args, harness.base_cfg(args))
    if prometheus_mode:
        cfg["prometheus_mode"] = True
    body, err = runner.run(source, cfg)
    # Un loader grande casi nunca lleva el payload dentro: se lo pide por HTTP a
    # un pastebin (MoonSec). Si el run pidio URLs y no hay cache, se descargan y
    # se repite UNA vez. Sin --http se comporta como siempre (respuesta de relleno).
    if getattr(args, "http", False) and body is not None:
        urls = harness.pending_urls(harness.LAST_RAW[0])
        missing = [u for u in urls if u not in harness.HTTP_CACHE]
        if missing:
            harness.fetch_urls(missing)
            body, err = runner.run(source, cfg)
    if body is None:
        harness.save_raw(args.raw)
        runner.finish()
        # No complete ENVLOG-BEGIN/END block means the trace logger failed (or
        # timed out before it could close one). Return a short, valid Lua
        # comment rather than leaking harness stdout/stderr into the dump.
        with open(out_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("-- [ERROR] Stopped due to: Environment logger did not return a complete trace.\n")
        print("[*] Stopped due to environment logger error", file=sys.stderr)
        return out_path
    runner.finish()
    harness.save_raw(args.raw)
    body = harness.take_p2d(body, cache_path, args.studio)
    body = harness.p2d_miss(body, cache_path)
    chunks, body = harness.take_chunks(body)
    parts, rec_summary, body = harness.take_recover(body)
    body, strings = trace.take_strings(body)
    artifacts = harness.write_artifacts(parts, chunks, out_path, getattr(args, "chunks", None))
    # A completed run is not automatically a dump. In particular, VM-only
    # scripts can finish without exposing any statement or source payload; do
    # not ship the CatLog banner as if it were recovered program code.
    if trace.stmt_count(body) == 0:
        with open(out_path, "w", encoding="utf-8", newline="\n") as f:
            f.write("")
        print("[*] no executable script code was observed; no dump produced", file=sys.stderr)
        shutil.rmtree(workdir, ignore_errors=True)
        return out_path
    body = trace.recover_note(body, rec_summary, len(artifacts)) or body
    text = trace.render(trace.header(input_path) + body, args, preamble=False)
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    if strings is not None:
        with open(re.sub(r"(\.[^.]+)$", ".strings.txt", out_path), "w", encoding="utf-8") as f:
            f.write(strings)
    trace.status_line(body)
    shutil.rmtree(workdir, ignore_errors=True)
    return out_path


HOST_MARKERS = ("No such file or directory", "Permission denied", "Exec format error",
                "is not available on this host", "Errno")


def _host_problem(exc: BaseException) -> bool:
    """A deployment problem is not a problem with the user's script."""
    if isinstance(exc, (FileNotFoundError, PermissionError, SystemExit)):
        return True
    return any(marker in str(exc) for marker in HOST_MARKERS)


def deobfuscate(input_path, source, out_path, args):
    """Never let a host problem reach the log as a traceback.

    A missing or non-executable Luau binary used to surface as a subprocess
    traceback full of absolute paths. Those paths are somebody's home directory
    and none of a Discord user's business. Everything host-shaped is caught here
    and turned into one sentence, without paths.
    """
    try:
        return _deobfuscate(input_path, source, out_path, args)
    except (Exception, SystemExit) as exc:          # noqa: BLE001
        if not _host_problem(exc):
            raise
        detail = str(exc) if isinstance(exc, SystemExit) else type(exc).__name__
        if not detail or "Traceback" in detail:
            detail = "the engine could not start"
        print("[!] " + detail, file=sys.stderr)
        sys.exit(2)
