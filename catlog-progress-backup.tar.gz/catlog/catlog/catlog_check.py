#!/usr/bin/env python3
"""catlog_check: comprobaciones de CatLog sobre si mismo.

No es un deobfuscador: es el sanity check que evita que CatLog se crea sus
propios resultados. Tres comprobaciones, todas verificables:

  1. COHERENCIA traza <-> payload: los literales que aparecen en la traza
     (`print`, `warn`, un nombre de propiedad) tienen que estar TAMBIEN en el
     bytecode decodificado. Si no, la traza esta inventando algo (o el payload
     no es el que se ejecuto). Este check salio de un fallo real: la traza decia
     `print(hello)` y el bytecode solo tenia `print("hello")`.

  2. TRAZA PARSEABLE: la salida de CatLog tiene que compilar como Luau.

  3. SIN TERCEROS POR DEFECTO: si no se pide --allow-external, la salida no
     puede venir de una herramienta ajena.

uso: python3 deobf/catlog_check.py <muestra.lua> [<salida.lua>]
"""
import argparse
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
LUAU_COMPILE = os.path.join(os.environ.get("LUAU_BIN", "/home/user/.luau-bin"), "luau-compile")


# palabras del propio lenguaje / andamiaje: no son evidencia de nada
KEYWORDS = {"function", "if", "then", "else", "elseif", "end", "for", "while", "do", "return",
            "local", "and", "or", "not", "in", "repeat", "until", "break", "continue",
            "spawn", "defer", "delay", "wait", "task", "pcall", "xpcall", "table", "string",
            "math", "coroutine", "print", "warn", "typeof", "tostring", "tonumber", "pairs", "ipairs"}


def literals_in_trace(text):
    """Identificadores y cadenas que la traza usa como llamadas o textos."""
    calls = set(re.findall(r"\b([A-Za-z_]\w{2,})\s*\(", text))
    strings = set(re.findall(r'"([^"\\\n]{3,60})"', text))
    return calls | strings


def contains(payload, token):
    """¿el literal aparece en el payload como bytes (ascii o utf-16le)?"""
    b = payload
    return token.encode("latin-1", "ignore") in b or token.encode("utf-16-le", "ignore") in b


def check_payload_coherence(sample, out):
    """Comprueba que la traza no inventa: todo literal suyo esta en el payload."""
    rec = re.sub(r"\.[^.]+$", "", out) + ".recovered"
    if not os.path.isdir(rec):
        return None, "no hay payloads recuperados (nada que comparar)"
    blobs = []
    for f in sorted(os.listdir(rec)):
        if f.endswith((".bin", ".lua")):
            blobs.append(open(os.path.join(rec, f), "rb").read())
    if not blobs:
        return None, "no hay payloads"
    joined = b"".join(blobs)
    text = open(out, encoding="utf-8", errors="replace").read()
    text = "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("--"))
    lits = {t for t in literals_in_trace(text) if t not in KEYWORDS}
    if not lits:
        return None, "la traza no tiene literales"
    missing = sorted(t for t in lits if not contains(joined, t))
    return missing, "%d/%d literales presentes en el payload" % (len(lits) - len(missing), len(lits))


def check_parses(out):
    if not os.path.isfile(out):
        return ["no hay salida"], "sin fichero de salida"
    if not os.path.isfile(LUAU_COMPILE):
        return None, "sin luau-compile"
    r = subprocess.run([LUAU_COMPILE, out], capture_output=True)
    ok = b"SyntaxError" not in (r.stdout + r.stderr)
    return ([] if ok else ["no compila"]), ("compila como Luau" if ok else "NO compila")


def check_no_third_party(out):
    if not os.path.isfile(out):
        return ["no hay salida"], "sin fichero de salida"
    text = open(out, encoding="utf-8", errors="replace").read(600)
    marks = ["Segunda opinion: SL", "Devirtualizado con", "deobfuscated at", "fuente estatica"]
    hit = [m for m in marks if m in text]
    return (hit or []), ("motor propio" if not hit else "viene de herramienta ajena: " + ", ".join(hit))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sample")
    ap.add_argument("output", nargs="?")
    args = ap.parse_args()
    out = args.output or tempfile.mktemp(suffix=".lua")
    if not args.output:
        env = dict(os.environ, LUAU_BIN=os.environ.get("LUAU_BIN", "/home/user/.luau-bin"))
        subprocess.run([sys.executable, os.path.join(HERE, "deob.py"), args.sample,
                        "-o", out, "--timeout", "90", "--recover"], env=env,
                       capture_output=True)
    fails = 0
    for name, fn in (("coherencia traza/payload", lambda: check_payload_coherence(args.sample, out)),
                     ("traza parseable", lambda: check_parses(out)),
                     ("motor propio", lambda: check_no_third_party(out))):
        bad, msg = fn()
        if bad is None:
            print("SKIP  %-26s %s" % (name, msg))
            continue
        print(("PASS  " if not bad else "FAIL  ") + "%-26s %s" % (name, msg))
        if bad:
            fails += 1
            for b in bad[:8]:
                print("        - no esta: %r" % b)
    print("\n==== %d fallo(s) ====" % fails)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
