"""
CatLog runs Lua(u) scripts in its fake Roblox/executor runtime and writes an
operation trace. Luraph v14/v15 inputs additionally use the bundled MIT-licensed
VM lifter for static source recovery where the specific VM layout is supported.
"""
import argparse
import os
import re
import subprocess
import sys
import threading
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import engine  # noqa: E402

PYPY_MIN_SIZE = 400_000


def parser():
    ap = argparse.ArgumentParser(
        prog="deob.py",
        description="Execute a script in a fake Roblox and write its behaviour trace.")
    ap.add_argument("input", help="script to run (.lua/.luau/.txt)")
    ap.add_argument("-o", "--output", help="output file (default: <input folder>/output/<name>)")
    ap.add_argument("--allow-external", action="store_true",
                    help="permitir herramientas de terceros (no es el camino normal: CatLog hace el trabajo)")
    ap.add_argument("--studio", action="store_true",
                    help="run inside Roblox Studio (native datatypes) instead of the offline model")
    ap.add_argument("--studio-wait", type=int, default=60, help=argparse.SUPPRESS)
    ap.add_argument("--port", type=int, default=34873, help=argparse.SUPPRESS)
    ap.add_argument("--timeout", type=int, default=60, help="seconds before giving up (default 60)")
    ap.add_argument("--budget", type=int, default=None,
                    help="seconds of script time the runtime may spend (default: same as --timeout)")
    ap.add_argument("--input-text", default=None,
                    help="text the script would receive from the user (getUserInput)")
    ap.add_argument("--executor", default=None, help="name identifyexecutor() should return")
    ap.add_argument("--raw", default=None, help="also write the raw runtime log here")
    ap.add_argument("--cfg", action="append", default=[], metavar="KEY=VALUE",
                    help="advanced switch (repeated)")
    ap.add_argument("--http", action="store_true",
                    help="fetch the URLs the script asks for (cached in ~/.cache/deobf/http) "
                         "and give them to the script as real HTTP responses")
    ap.add_argument("--chunks", default=None, metavar="DIR",
                    help="write the chunks the script decoded at runtime into DIR "
                         "(every loadstring payload, hex-decoded, one file each)")
    ap.add_argument("--recover", action="store_true",
                    help="recover decoded payloads even when the run aborts: the strings the "
                         "obfuscator builds (string.char/rep, loadstring) are dumped to "
                         "<output>.recovered.lua next to --chunks")
    ap.add_argument("--keep-harness", action="store_true", help="keep the generated harness file")
    ap.add_argument("--no-tidy", action="store_true", help="do not re-indent the trace")
    ap.add_argument("--no-fold", action="store_true", help="do not fold repeated statements")
    ap.add_argument("--keep-preamble", action="store_true",
                    help="keep the environment probes at the top of the trace")
    ap.add_argument("--debug", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--obfuscator", default=None, help=argparse.SUPPRESS)
    ap.add_argument("--pypy", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--no-pypy", action="store_true", help=argparse.SUPPRESS)
    ap.add_argument("--detect", action="store_true", help=argparse.SUPPRESS)
    return ap


def decode_source(raw):
    """Lee el fuente como lo leeria el cliente: un byte por caracter.

    Muchos loaders usan cadenas no-ASCII y hacen aritmetica con su longitud
    (`#[[<Ñ x7>]]`). Si el fichero viene en UTF-8 y se carga como UTF-8, cada Ñ
    ocupa 2 bytes: la resta se desalinea y el VM revienta con "attempt to call a
    nil value" en mitad de su decoder (comprobado en MoonSec, donde `o[-5]`
    salia nil). Roblox carga los scripts byte a byte, asi que UTF-8 se convierte
    a latin-1 cuando todos los caracteres caben en un byte; si no caben, se deja
    tal cual.
    """
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1")
    if all(ord(c) < 128 for c in text):
        return text
    if all(ord(c) < 256 for c in text):
        return text.encode("latin-1").decode("latin-1")
    return text


def run_deep(fn, *a):
    """`fold.parse` walks the invocation tree recursively, so a script whose
    trace nests thousands of calls deep (a detector replaying one check 4096
    times) overflows CPython's default stack even though nothing is wrong with
    the script. Run the work in a thread with a large stack and a raised
    recursion limit; exceptions from the worker are re-raised here."""
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 200000))
    started = False
    for mb in (512, 256, 64):
        try:
            threading.stack_size(mb * 1024 * 1024)
            th = threading.Thread(target=_worker, args=(fn, a))
            th.start()
            started = True
            break
        except (ValueError, RuntimeError, MemoryError):
            continue
    if not started:
        threading.stack_size(0)
        th = threading.Thread(target=_worker, args=(fn, a))
        th.start()
    th.join()
    if "e" in _BOX:
        err = _BOX.pop("e")
        raise err
    return _BOX.pop("r", None)


_BOX = {}


def _worker(fn, a):
    try:
        _BOX["r"] = fn(*a)
    except BaseException as e:  # noqa: BLE001 - re-raised on the caller side
        _BOX["e"] = e


def main():
    args = parser().parse_args()
    if not os.path.exists(args.input):
        sys.exit("[!] missing input: %s" % args.input)
    if args.budget is None:
        args.budget = args.timeout
    out = args.output or os.path.join(os.path.dirname(os.path.abspath(args.input)),
                                      "output", os.path.basename(args.input))
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(args.input, "rb") as f:
        source = decode_source(f.read())
    run_deep(engine.deobfuscate, args.input, source, out, args)
    print("[+] result: " + out, file=sys.stderr)


if __name__ == "__main__":
    main()
