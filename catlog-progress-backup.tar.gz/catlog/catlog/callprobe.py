#!/usr/bin/env python3
"""callprobe: localiza la expresion exacta que revienta dentro de un loader.

Los obfuscadores abortan con "attempt to call a nil value" sin decir cual. Aqui
se parsea el script con `luau-ast` y se envuelve CADA llamada en un ayudante que
la ejecuta con pcall: si falla, imprime el texto de la expresion, el error y el
fragmento de fuente. Es diagnostico, no forma parte de la salida normal.

uso:  python3 deobf/callprobe.py <script.lua> -o probe.luau [--max-calls N]
"""
import argparse
import json
import os
import subprocess
import sys

LUAU_AST = os.path.join(os.environ.get("LUAU_BIN", "/home/user/.luau-bin"), "luau-ast")

PREAMBLE = r"""
local __REPORTED = false
local __DEPTH = 0
local function __fmt(v)
	if type(v) == "table" then
		local ok, s = pcall(function() return tostring(v) end)
		return ok and s or "table"
	end
	return tostring(v)
end
local function __T(fn, what, ...)
	if __DEPTH > 40 then return fn(...) end
	__DEPTH += 1
	local r = table.pack(pcall(fn, ...))
	__DEPTH -= 1
	if not r[1] then
		if not __REPORTED then
			__REPORTED = true
			print("\0NILCALL " .. what)
			print("\0NILERR " .. tostring(r[2]))
			print(traceback and traceback() or debug.traceback())
		end
		error(r[2], 0)
	end
	return table.unpack(r, 2, r.n)
end
"""


def ast_of(path):
    r = subprocess.run([LUAU_AST, path], capture_output=True)
    if r.returncode != 0:
        sys.exit("[!] luau-ast fallo: " + r.stderr.decode("latin-1")[:400])
    return json.loads(r.stdout.decode("latin-1", "replace"))


def pos(loc):
    """'l1,c1 - l2,c2' -> (l1, c1, l2, c2)"""
    a, _, b = loc.partition(" - ")
    l1, c1 = (int(x) for x in a.split(","))
    l2, c2 = (int(x) for x in b.split(","))
    return l1, c1, l2, c2


def walk(node, out):
    if isinstance(node, dict):
        if node.get("type") == "AstExprCall":
            out.append(node)
        for v in node.values():
            walk(v, out)
    elif isinstance(node, list):
        for v in node:
            walk(v, out)


def lua_str(text, maxlen=160):
    """literal de cadena Lua seguro: solo [A-Za-z0-9 _.[]()] y las comillas
    simples se pasan a pulgadas, asi no hay forma de romper la sintaxis."""
    s = text[:maxlen].replace("\n", " ").replace("\r", " ").replace("\t", " ")
    keep = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 _.,:[]()+-*/%#=")
    s = "".join(c if c in keep else ("'" if c == '"' else "?") for c in s)
    return '"' + s + '"'


def raw_index_map(raw):
    """raw(utf-8) byte offset -> indice de caracter en el texto decodificado.

    luau-ast da columnas en BYTES del fichero; el fuente que se instrumenta esta
    decodificado (un byte por caracter). Sin este mapa, un solo caracter
    multi-byte desplaza todas las ediciones (bug real: `[[<Ñ x7>]]` desalineaba
    los envoltorios 7 bytes y generaba Luau invalido).
    """
    idx = []
    i = 0
    j = 0
    n = len(raw)
    while i < n:
        c = raw[i]
        if c < 0x80:
            step = 1
        elif 0xC2 <= c <= 0xDF:
            step = 2
        elif 0xE0 <= c <= 0xEF:
            step = 3
        elif 0xF0 <= c <= 0xF4:
            step = 4
        else:
            step = 1
        for _ in range(step):
            idx.append(j)
        i += step
        j += 1
    idx.append(j)
    return idx


def offsets(src, loc, rawmap=None):
    """(line, col) de luau-ast (AMBOS 0-based) -> indice en el fuente"""
    lines = src.split("\n")
    start = sum(len(l) + 1 for l in lines[: loc[0]])
    off = start + loc[1]
    if rawmap is not None:
        # el offset viene en bytes del fichero: se convierte a indice de caracter
        off = rawmap[min(off, len(rawmap) - 1)]
    return off


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--max-calls", type=int, default=0, help="0 = todas")
    args = ap.parse_args()

    raw = open(args.input, "rb").read()
    try:
        from deob import decode_source
        src = decode_source(raw)
    except Exception:
        src = raw.decode("latin-1")
    tree = ast_of(args.input)
    rawmap = raw_index_map(raw) if len(raw) != len(src) else None
    calls = []
    walk(tree, calls)
    # solo las llamadas cuyo texto no sea gigantesco (el cuerpo de un VM entero)
    spans = []
    for c in calls:
        l1, c1, l2, c2 = pos(c["location"])
        if (l1, c1) == (l2, c2):
            continue
        a, b = offsets(src, (l1, c1), rawmap), offsets(src, (l2, c2), rawmap)
        spans.append((a, b))
    spans.sort(key=lambda s: (s[0], -s[1]))
    if args.max_calls:
        spans = spans[: args.max_calls]

    # solo llamadas NO anidadas: envolver una dentro de otra rompe la sintaxis
    # de las llamadas solapadas se queda la MAS PEQUENA (la exterior suele ser
    # medio programa); las pequenas son las que dan diagnostico util
    keep = []
    for a, b in sorted(spans, key=lambda s: (s[1] - s[0])):
        if any(not (b <= x or a >= y) for x, y in keep):
            continue
        keep.append((a, b))
    edits = {}
    for a, b in keep:
        text = src[a:b]
        if "\n" in text and len(text) > 4000:
            continue
        if "__" in text and "T(" in text:
            continue            # ya instrumentada: envolver dos veces no aporta
        edits.setdefault(a, []).append(("open", a))
        edits.setdefault(b, []).append(("close", b))
    pieces = []
    last = 0
    n = 0
    for at in sorted(edits):
        pieces.append(src[last:at])
        for kind, lit in sorted(edits[at], key=lambda e: e[0] != "close"):
            if kind == "open":
                pieces.append("__T(function(...) return ")
            else:
                pieces.append(' end, "site@' + str(lit) + '")')
            n += 1
        last = at
    pieces.append(src[last:])
    spans = [1] * n
    body = "".join(pieces)
    body = PREAMBLE + "\n" + body
    open(args.output, "w", encoding="latin-1", newline="\n").write(body)
    print("[*] %d envoltorios -> %s" % (n, args.output))


if __name__ == "__main__":
    main()
