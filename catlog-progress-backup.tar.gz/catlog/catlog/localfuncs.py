"""
Arbol sintactico de Luau (luau-ast) para los pases de texto de la traza.

Solo queda el parser: la reescritura de `local f = function` a
`local function f` era parte del lifting de bytecode y ya no existe.
"""
try:
    from binpath import tool as _tool
except ImportError:  # imported as a package
    from .binpath import tool as _tool
import json
import os
import subprocess
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


def _ast(text):
    with tempfile.NamedTemporaryFile("w", suffix=".luau", delete=False, encoding="utf-8", newline="\n") as f:
        f.write(text)
        path = f.name
    try:
        out = subprocess.run([_tool("luau-ast"), path],
                             capture_output=True).stdout
    finally:
        os.remove(path)
    return json.loads(out.decode("latin-1"))["root"]


def _walk(n, fn):
    if isinstance(n, dict):
        fn(n)
        for v in n.values():
            if isinstance(v, (dict, list)):
                _walk(v, fn)
    elif isinstance(n, list):
        for v in n:
            _walk(v, fn)

