#!/usr/bin/env python3
"""luaobf: saca la fuente de un script LuaObfuscator.

Cómo funciona esta familia (comprobado sobre la muestra del corpus):

  * El script es un **intérprete propio**: `v23(payload_cifrado, clave, ...)`
    devuelve una función que ejecuta el bytecode de un VM propio (no hay
    `loadstring`, no hay `string.dump`, no hay chunk Lua estándar que decompilar).
  * El payload viene cifrado con XOR repetido; la clave se deriva **en el propio
    script** con su función `v7(semilla, clave_del_vm)`.

Por eso la fuente se saca **ejecutando el intérprete del obfuscador en un Lua 5.1
real** (lupa) con un entorno instrumentado: es lo que hace un cliente de verdad.
Lo que se puede recuperar así, en orden de fidelidad:

  1. el bytecode del VM (la "cinta" de instrucciones) que se pasa a `v40`,
  2. las llamadas del payload ya resueltas (print(...), game:GetService(...), etc.)
     con sus argumentos, que es comportamiento y no fuente,
  3. la fuente Luau reconstruida a partir de (2) para las operaciones que se
     observan (nunca se inventan ramas que no se ejecutan).

`decompile` es best-effort: si el payload trae un chunk Lua 5.1 estándar (esta
familia a veces lo hace) se decompila con unluac.

uso:
    python3 deobf/luaobf.py <muestra.lua> [-o salida.lua] [--json informe.json]
"""
import argparse
import json
import os
import shutil
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

BIT32_STUB = r'''
local function bxor(a, b)
  local r, bit = 0, 1
  for i = 1, 32 do
    local x, y = a % 2, b % 2
    if x ~= y then r = r + bit end
    a, b, bit = (a - x) / 2, (b - y) / 2, bit * 2
  end
  return r
end
bit32, bit = { bxor = bxor }, { bxor = bxor }
'''

# entorno que ve el payload: mock minimo de Roblox + grabadora de llamadas
SPY = r'''
CALLS, GETS = {}, {}
local real_print = print
local function render(v)
  if type(v) == "string" then return string.format("%q", v) end
  return tostring(v)
end
local function record(name, args, n)
  local parts = {}
  for i = 1, n do parts[i] = render(args[i]) end
  CALLS[#CALLS + 1] = { name = name, args = table.concat(parts, ", "), n = n }
end
local function spyfn(name, f)
  return function(...)
    record(name, {...}, select("#", ...))
    return f(...)
  end
end
local function spytable(name, t)
  return setmetatable({}, { __index = function(_, k)
    local v = t[k]
    if type(v) == "function" then
      return function(self, ...)
        if type(self) == "table" and rawequal(self, _) then
          record(name .. ":" .. tostring(k), {...}, select("#", ...))
          return v(t, ...)
        end
        record(name .. "." .. tostring(k), {self, ...}, select("#", ...) + 1)
        return v(self, ...)
      end
    end
    return v
  end })
end
-- objetos mock: cualquier índice da otro objeto mock (como una Instance de Roblox)
local function mockInstance(class)
  return setmetatable({ ClassName = class }, {
    __index = function(t, k)
      GETS[#GETS + 1] = class .. "." .. tostring(k)
      return mockInstance(tostring(k))
    end,
    __tostring = function(t) return t.ClassName end,
  })
end
ENV = {
  print = spyfn("print", real_print),
  warn = spyfn("warn", real_print),
  string = spytable("string", string),
  table = spytable("table", table),
  math = spytable("math", math),
  bit32 = bit32, bit = bit,
  tostring = tostring, tonumber = tonumber, type = type, select = select,
  pcall = pcall, setmetatable = setmetatable, getmetatable = getmetatable,
  unpack = unpack, next = next, pairs = pairs, ipairs = ipairs, error = error,
  game = mockInstance("DataModel"),
  workspace = mockInstance("Workspace"),
  script = mockInstance("Script"),
  Instance = { new = function(c) return mockInstance(c) end },
  task = { wait = spyfn("task.wait", function() return 0 end),
           spawn = function(f, ...) if type(f) == "function" then f(...) end end,
           delay = function(_, f, ...) if type(f) == "function" then f(...) end end },
  wait = spyfn("wait", function() return 0 end),
  typeof = function(v) if type(v) == "table" then return "Instance" end return type(v) end,
}
ENV._G = ENV
setmetatable(ENV, { __index = function(_, k)
  GETS[#GETS + 1] = tostring(k)
  local v = _G[k]
  if type(v) == "function" then return spyfn(tostring(k), v) end
  return v
end })
getfenv = function() return ENV end
setfenv = function(f) return f end
-- el VM del obfuscador ejecuta su propio bytecode: aqui se compila con el
-- loadstring real, guardado antes de instalar el espia
REAL_LOAD = _G.loadstring
function COMPILE(s) return REAL_LOAD(s) end
'''


def key_from_script(src):
    """La clave del payload la deriva el propio script: v7(semilla, clave_vm)."""
    m = re.search(r'return\s+v\d+\(\s*v\d+\("((?:[^"\\]|\\.)*)","((?:[^"\\]|\\.)*)"\)', src)
    if not m:
        return None, None, None
    def unesc(s):
        return bytes(int(x) for x in re.findall(r"\\(\d+)", s))
    payload, seed = unesc(m.group(1)), unesc(m.group(2))
    try:
        import lupa.lua51 as l51
    except ImportError:
        return payload, seed, None
    rt = l51.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(BIT32_STUB)
    head = src[: src.index("local v8=tonumber")] if "local v8=tonumber" in src else src[:4000]
    runner = rt.eval("function(code) local g = assert(loadstring(code .. ' return v7')) return g() end")
    v7 = runner(head)
    key = v7(payload, seed)
    return payload, seed, bytes(ord(c) for c in key)


TAPE_HOOK = r'''
-- captura de la "cinta" (bytecode propio del VM) y su proto
function TAPEDUMP()
  local parts = {}
  local function ser(v, depth)
    local tv = type(v)
    if tv == "string" then return string.format("%q", v) end
    if tv ~= "table" then return tostring(v) end
    if depth > 2 then return "{...}" end
    local out = {}
    for i = 1, #v do out[i] = ser(v[i], depth + 1) end
    return "{" .. table.concat(out, ",") .. "}"
  end
  return ser(TAPE, 0)
end
'''


def capture_tape(src):
    """Ejecuta el script capturando la cinta de bytecode que pasa al interprete."""
    try:
        import lupa.lua51 as l51
    except ImportError:
        return None, "lupa[lua51] no instalado"
    m = re.search(r"return\s+v(\d+)\(v(\d+)\(\),\{\},v(\d+)\)\(\.\.\.\);", src)
    if not m:
        return None, "no se localiza la llamada al interprete"
    call = m.group(0)
    vm, reader, key = m.group(1), m.group(2), m.group(3)
    patched = src.replace(call, "local __T = v%s(); TAPE = __T; return v%s(__T,{},v%s)(...);"
                          % (reader, vm, key))
    rt = l51.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(BIT32_STUB)
    rt.execute(SPY)
    rt.execute(TAPE_HOOK)
    setter = rt.eval("function(s) SRC2 = s end")
    setter(patched)
    rt.execute(r'''
local f, e = COMPILE(SRC2)
if not f then OK2, ERR2 = false, tostring(e) else
  local ok, err = pcall(f)
  OK2, ERR2 = ok, tostring(err)
end
''')
    if rt.eval("type(TAPE)") == b"nil" or rt.eval("type(TAPE)") == "nil":
        return None, "el VM no expuso la cinta"
    return rt.eval("TAPEDUMP()"), str(rt.eval("ERR2") or "")


def run_in_lua51(src):
    """Ejecuta el script con el entorno espía y devuelve lo observado."""
    try:
        import lupa.lua51 as l51
    except ImportError:
        return {"error": "lupa[lua51] no instalado"}
    rt = l51.LuaRuntime(unpack_returned_tuples=True)
    rt.execute(BIT32_STUB)
    rt.execute(SPY)
    setter = rt.eval("function(s) SRC = s end")
    setter(src)
    rt.execute(r'''
local f, e = COMPILE(SRC)
if not f then OK, ERR = false, tostring(e) else
  local ok, err = pcall(f)
  OK, ERR = ok, tostring(err)
end
''')
    calls = rt.eval("CALLS")
    gets = rt.eval("GETS")
    out = {"ok": bool(rt.eval("OK")), "error": str(rt.eval("ERR") or ""),
           "calls": [], "gets": []}
    for i in range(1, (len(calls) or 0) + 1):
        out["calls"].append({"name": calls[i]["name"], "args": calls[i]["args"]})
    for i in range(1, (len(gets) or 0) + 1):
        out["gets"].append(gets[i])
    return out


def render_source(obs, payload_key=None):
    """Reconstruye lo que el script HIZO, como Luau legible y honesto."""
    lines = [
        "-- recovered by deobf/luaobf.py (LuaObfuscator)",
        "-- metodo: se ejecuta el interprete del propio obfuscador en un Lua 5.1 real",
        "-- con un entorno instrumentado; lo de abajo son las operaciones observadas.",
        "-- NO es el fuente original: las ramas que no se ejecutaron no aparecen.",
        "",
    ]
    if payload_key:
        lines.append("-- payload: %d bytes, clave derivada por el script: %s" %
                     (payload_key[0], payload_key[1]))
    if obs.get("error"):
        lines.append("-- aviso: el payload aborto: %s" % obs["error"][:120])
    for c in obs.get("calls", []):
        name = c["name"]
        if ":" in name:
            obj, meth = name.split(":", 1)
            lines.append("%s:%s(%s)" % (obj, meth, c["args"]))
        else:
            lines.append("%s(%s)" % (name, c["args"]))
    if len(lines) <= 6 and not obs.get("calls"):
        lines.append("-- (el payload no produjo ninguna llamada observable)")
    return "\n".join(lines) + "\n"


BACKEND = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backends", "luaobf_leakd")


def static_source(src):
    """Fuente real via backend estatico (LeakD, MIT), si node esta disponible.

    Devuelve (codigo, None) o (None, motivo). El codigo solo se acepta si
    compila como Luau: un decompilador que escupe basura no cuenta.
    """
    if not shutil.which("node"):
        return None, "node no esta instalado"
    if not os.path.isfile(os.path.join(BACKEND, "index.js")):
        return None, "backend ausente: " + BACKEND
    out = tempfile.mktemp(suffix=".lua")
    inp = tempfile.mktemp(suffix=".lua")
    with open(inp, "w", encoding="utf-8") as f:
        f.write(src)
    try:
        r = subprocess.run([shutil.which("node"), os.path.join(BACKEND, "index.js"), inp, "--out", out],
                           capture_output=True, text=True, timeout=600, cwd=BACKEND)
    except subprocess.TimeoutExpired:
        return None, "el backend estatico agoto el tiempo"
    os.unlink(inp)
    if not os.path.isfile(out):
        return None, "el backend no escribio salida: " + (r.stderr or "").strip()[-300:]
    code = open(out, encoding="utf-8", errors="replace").read()
    os.unlink(out)
    if not _parses(code):
        return None, "la salida del backend no compila como Luau"
    return code, None


def _parses(code):
    luau_compile = os.path.join(os.environ.get("LUAU_BIN", "/home/user/.luau-bin"), "luau-compile")
    if not os.path.isfile(luau_compile):
        return True                       # sin compilador no se puede dudar
    path = tempfile.mktemp(suffix=".luau")
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)
    try:
        r = subprocess.run([luau_compile, path], capture_output=True, timeout=120)
        return b"SyntaxError" not in (r.stdout + r.stderr)
    finally:
        os.unlink(path)


def is_luaobfuscator(src):
    return "LOL!" in src or bool(re.search(r"local v\d+=string\.char;local v\d+=string\.byte", src))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    ap.add_argument("--json")
    args = ap.parse_args()
    raw = open(args.input, "rb").read()
    from deob import decode_source
    src = decode_source(raw)
    if not is_luaobfuscator(src):
        print("[!] no parece LuaObfuscator", file=sys.stderr)
    # 1) fuente real: backend estatico (decompila el VM). Si no hay node o no
    #    compila lo que devuelve, se sigue y se entrega lo observable.
    code, why = static_source(src)
    if code:
        out = args.output or os.path.splitext(args.input)[0] + ".luaobf.lua"
        open(out, "w", encoding="utf-8", newline="\n").write(code)
        print("fuente: estatica (backend LeakD, MIT) -- compila como Luau")
        print("->", out)
        return 0
    print("fuente estatica no disponible:", why, file=sys.stderr)

    payload, seed, key = key_from_script(src)
    obs = run_in_lua51(src)
    # la cinta de bytecode del VM se guarda como artefacto aparte (es el programa
    # que ejecuta el interprete, en su formato; no es fuente y no se disfraza)
    tape, tape_err = capture_tape(src)
    text = render_source(obs, (len(payload), key.hex()) if payload and key else None)
    if tape:
        tap = os.path.splitext(args.output or args.input)[0] + ".tape.txt"
        with open(tap, "w", encoding="utf-8", newline="\n") as f:
            f.write("-- cinta de bytecode del VM de LuaObfuscator (sin decompilar)\n")
            f.write(tape + "\n")
        text = text.replace("-- payload:", "-- cinta del VM: %s (bytecode, sin decompilar)\n-- payload:" % tap, 1)
    print("cinta del VM:", "capturada" if tape else ("no: " + str(tape_err)))
    out = args.output or os.path.splitext(args.input)[0] + ".luaobf.lua"
    open(out, "w", encoding="utf-8", newline="\n").write(text)
    print(obs.get("error") and ("aviso: " + obs["error"][:100]) or "run: ok")
    print("llamadas observadas:", len(obs.get("calls", [])))
    print("->", out)
    if args.json:
        json.dump(obs, open(args.json, "w"), indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
