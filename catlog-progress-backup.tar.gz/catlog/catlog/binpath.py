"""Locate the Luau CLI tools (luau, luau-ast).

The binaries are deliberately not committed. They are looked up in this order:

1. ``deobf/bin/`` (the historical location, what ``build_luau.py`` produces)
2. ``$LUAU_BIN``
3. ``$PATH``

Everything in the engine should ask this module instead of joining paths by
hand, so a missing binary fails with one clear message instead of a
FileNotFoundError from deep inside subprocess.
"""
from __future__ import annotations

import os
import platform
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(HERE, "bin")
LOCAL = os.path.join(os.path.dirname(HERE), ".luau-local")   # a build of your own

# ELF e_machine -> uname -m. A binary built for another CPU runs nowhere, and the
# error it gives ("Exec format error") says nothing useful, so it is checked here.
_ELF = {0x03: "i386", 0x28: "armv7l", 0x3E: "x86_64", 0xB7: "aarch64", 0xF3: "riscv64"}


def machine_of(path: str) -> str | None:
    """CPU a binary was built for, or None if it is not an ELF we recognise."""
    try:
        with open(path, "rb") as f:
            head = f.read(20)
    except OSError:
        return None
    if len(head) < 20 or head[:4] != b"\x7fELF":
        return None
    little = head[5] == 1
    value = int.from_bytes(head[18:20], "little" if little else "big")
    return _ELF.get(value)


def arch_problem(path: str) -> str | None:
    """'built for aarch64, this is x86_64' — or None when the binary fits."""
    built = machine_of(path)
    if built is None:
        return None                       # not ELF (a Windows .exe): leave it alone
    host = platform.machine()
    if built == host:
        return None
    if host == "arm64" and built == "aarch64":
        return None
    return f"built for {built}, this machine is {host}"


def is_tool_available(name: str) -> bool:
    """True if the tool exists, can be executed, and was built for this CPU."""
    path = tool(name)
    return (os.path.isfile(path) and os.access(path, os.X_OK)
            and arch_problem(path) is None)


def tool(name: str) -> str:
    """Absolute path to a Luau CLI tool, or a path that will fail loudly."""
    exe = name + (".exe" if os.name == "nt" else "")
    for candidate in (os.path.join(BIN, exe),
                      os.path.join(LOCAL, exe),
                      os.path.join(os.environ.get("LUAU_BIN", ""), exe)):
        if os.path.isfile(candidate):
            return candidate
    on_path = shutil.which(exe.rsplit(".exe", 1)[0]) or shutil.which(exe)
    if on_path:
        return on_path
    return os.path.join(BIN, exe)


def missing(name: str) -> None:
    """Exit without ever printing a path: this text can end up in a Discord reply."""
    exe = name + (".exe" if os.name == "nt" else "")
    sys.exit(f"{exe} is not available on this host. "
             f"Put it in the engine's bin directory, or point LUAU_BIN at one.")
